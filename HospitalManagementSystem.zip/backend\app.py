from flask import Flask, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from flask_jwt_extended import JWTManager
from datetime import timedelta
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Initialize extensions
db = SQLAlchemy()
jwt = JWTManager()

def create_app():
    app = Flask(__name__)
    
    # Configuration
    app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'dev-secret-key-change-in-production')
    app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URL', 'sqlite:///hospital.db')
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['JWT_SECRET_KEY'] = os.getenv('JWT_SECRET_KEY', 'jwt-secret-key-change-in-production')
    app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(hours=24)
    
    # Initialize extensions with app
    db.init_app(app)
    jwt.init_app(app)
    CORS(app, origins=['http://localhost:3000', 'http://localhost:3001'])
    
    # Register blueprints
    from backend.routes.beds import beds_bp
    from backend.routes.staff import staff_bp
    from backend.routes.patients import patients_bp
    from backend.routes.allocations import allocations_bp
    from backend.routes.dashboard import dashboard_bp
    
    app.register_blueprint(beds_bp, url_prefix='/api/beds')
    app.register_blueprint(staff_bp, url_prefix='/api/staff')
    app.register_blueprint(patients_bp, url_prefix='/api/patients')
    app.register_blueprint(allocations_bp, url_prefix='/api/allocations')
    app.register_blueprint(dashboard_bp, url_prefix='/api/dashboard')
    
    # Add a simple home route
    @app.route('/')
    def home():
        return jsonify({
            'message': 'Hospital Management System API',
            'version': '1.0.0',
            'status': 'running',
            'endpoints': {
                'dashboard': '/api/dashboard',
                'beds': '/api/beds',
                'staff': '/api/staff',
                'patients': '/api/patients',
                'allocations': '/api/allocations'
            }
        })
    
    # Create tables
    with app.app_context():
        db.create_all()
        # Initialize sample data if needed
        from backend.utils.sample_data import initialize_sample_data
        initialize_sample_data()
    
    return app

if __name__ == '__main__':
    app = create_app()
    app.run(debug=True, host='0.0.0.0', port=5000) 