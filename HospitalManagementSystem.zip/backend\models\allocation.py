from backend.app import db
from datetime import datetime
from enum import Enum
import uuid

class AllocationStatus(Enum):
    ACTIVE = "Active"
    COMPLETED = "Completed"
    CANCELLED = "Cancelled"

class BedAllocation(db.Model):
    __tablename__ = 'bed_allocations'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    bed_id = db.Column(db.String(36), db.ForeignKey('beds.id'), nullable=False)
    patient_id = db.Column(db.String(36), db.ForeignKey('patients.id'), nullable=False)
    allocated_by = db.Column(db.String(36), db.ForeignKey('staff.id'), nullable=False)
    start_date = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    end_date = db.Column(db.DateTime)
    status = db.Column(db.Enum(AllocationStatus), default=AllocationStatus.ACTIVE, nullable=False)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    allocator = db.relationship('Staff', foreign_keys=[allocated_by])
    
    def __repr__(self):
        return f'<BedAllocation {self.bed.bed_number} -> {self.patient.full_name}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'bed_id': self.bed_id,
            'bed_number': self.bed.bed_number if self.bed else None,
            'ward': self.bed.ward if self.bed else None,
            'patient_id': self.patient_id,
            'patient_name': self.patient.full_name if self.patient else None,
            'allocated_by': self.allocated_by,
            'allocator_name': self.allocator.full_name if self.allocator else None,
            'start_date': self.start_date.isoformat() if self.start_date else None,
            'end_date': self.end_date.isoformat() if self.end_date else None,
            'status': self.status.value,
            'notes': self.notes,
            'duration_days': self.duration_days,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
    
    @property
    def duration_days(self):
        """Calculate duration of allocation in days"""
        if self.end_date:
            end = self.end_date
        else:
            end = datetime.utcnow()
        
        return (end - self.start_date).days
    
    def end_allocation(self, end_date=None):
        """End the bed allocation"""
        self.end_date = end_date or datetime.utcnow()
        self.status = AllocationStatus.COMPLETED
        self.updated_at = datetime.utcnow()
        
        # Make bed available
        if self.bed:
            self.bed.set_available()
        
        db.session.commit()
    
    @staticmethod
    def allocate_bed(bed_id, patient_id, allocated_by, notes=None):
        """Allocate a bed to a patient"""
        from backend.models.bed import Bed, BedStatus
        
        bed = Bed.query.get(bed_id)
        if not bed or bed.status != BedStatus.AVAILABLE:
            raise ValueError("Bed is not available for allocation")
        
        # Check if patient already has an active bed allocation
        existing_allocation = BedAllocation.query.filter_by(
            patient_id=patient_id,
            status=AllocationStatus.ACTIVE
        ).first()
        
        if existing_allocation:
            raise ValueError("Patient already has an active bed allocation")
        
        # Create new allocation
        allocation = BedAllocation(
            bed_id=bed_id,
            patient_id=patient_id,
            allocated_by=allocated_by,
            notes=notes
        )
        
        # Mark bed as occupied
        bed.set_occupied()
        
        db.session.add(allocation)
        db.session.commit()
        
        return allocation

class StaffAllocation(db.Model):
    __tablename__ = 'staff_allocations'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    staff_id = db.Column(db.String(36), db.ForeignKey('staff.id'), nullable=False)
    ward = db.Column(db.String(100), nullable=False)
    patient_id = db.Column(db.String(36), db.ForeignKey('patients.id'), nullable=True)  # Optional - for specific patient care
    allocated_by = db.Column(db.String(36), db.ForeignKey('staff.id'), nullable=False)
    start_date = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    end_date = db.Column(db.DateTime)
    shift_type = db.Column(db.String(20))  # Morning, Evening, Night
    status = db.Column(db.Enum(AllocationStatus), default=AllocationStatus.ACTIVE, nullable=False)
    priority = db.Column(db.Integer, default=1)  # 1=Low, 2=Medium, 3=High, 4=Critical
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    allocator = db.relationship('Staff', foreign_keys=[allocated_by])
    assigned_patient = db.relationship('Patient', foreign_keys=[patient_id])
    
    def __repr__(self):
        return f'<StaffAllocation {self.staff_member.full_name} -> {self.ward}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'staff_id': self.staff_id,
            'staff_name': self.staff_member.full_name if self.staff_member else None,
            'staff_role': self.staff_member.role.value if self.staff_member else None,
            'ward': self.ward,
            'patient_id': self.patient_id,
            'patient_name': self.assigned_patient.full_name if self.assigned_patient else None,
            'allocated_by': self.allocated_by,
            'allocator_name': self.allocator.full_name if self.allocator else None,
            'start_date': self.start_date.isoformat() if self.start_date else None,
            'end_date': self.end_date.isoformat() if self.end_date else None,
            'shift_type': self.shift_type,
            'status': self.status.value,
            'priority': self.priority,
            'priority_text': self.priority_text,
            'notes': self.notes,
            'duration_hours': self.duration_hours,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
    
    @property
    def priority_text(self):
        """Convert priority number to text"""
        priority_map = {1: 'Low', 2: 'Medium', 3: 'High', 4: 'Critical'}
        return priority_map.get(self.priority, 'Unknown')
    
    @property
    def duration_hours(self):
        """Calculate duration of allocation in hours"""
        if self.end_date:
            end = self.end_date
        else:
            end = datetime.utcnow()
        
        return round((end - self.start_date).total_seconds() / 3600, 2)
    
    def end_allocation(self, end_date=None):
        """End the staff allocation"""
        self.end_date = end_date or datetime.utcnow()
        self.status = AllocationStatus.COMPLETED
        self.updated_at = datetime.utcnow()
        db.session.commit()
    
    @staticmethod
    def allocate_staff(staff_id, ward, allocated_by, patient_id=None, shift_type=None, priority=1, notes=None):
        """Allocate staff to a ward or specific patient"""
        from backend.models.staff import Staff, StaffStatus
        
        staff = Staff.query.get(staff_id)
        if not staff or staff.status != StaffStatus.ACTIVE:
            raise ValueError("Staff member is not available for allocation")
        
        # Create new allocation
        allocation = StaffAllocation(
            staff_id=staff_id,
            ward=ward,
            patient_id=patient_id,
            allocated_by=allocated_by,
            shift_type=shift_type,
            priority=priority,
            notes=notes
        )
        
        db.session.add(allocation)
        db.session.commit()
        
        return allocation 