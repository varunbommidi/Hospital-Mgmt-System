from backend.app import db
from datetime import datetime
from enum import Enum
import uuid

class BedType(Enum):
    ICU = "ICU"
    GENERAL = "General"
    EMERGENCY = "Emergency"
    PEDIATRIC = "Pediatric"
    MATERNITY = "Maternity"
    SURGERY = "Surgery"

class BedStatus(Enum):
    AVAILABLE = "Available"
    OCCUPIED = "Occupied"
    MAINTENANCE = "Maintenance"
    CLEANING = "Cleaning"

class Bed(db.Model):
    __tablename__ = 'beds'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    bed_number = db.Column(db.String(20), unique=True, nullable=False)
    ward = db.Column(db.String(100), nullable=False)
    floor = db.Column(db.Integer, nullable=False)
    room_number = db.Column(db.String(20), nullable=False)
    bed_type = db.Column(db.Enum(BedType), nullable=False)
    status = db.Column(db.Enum(BedStatus), default=BedStatus.AVAILABLE, nullable=False)
    has_ventilator = db.Column(db.Boolean, default=False)
    has_monitor = db.Column(db.Boolean, default=False)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    allocations = db.relationship('BedAllocation', backref='bed', lazy=True)
    
    def __repr__(self):
        return f'<Bed {self.bed_number} - {self.ward}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'bed_number': self.bed_number,
            'ward': self.ward,
            'floor': self.floor,
            'room_number': self.room_number,
            'bed_type': self.bed_type.value,
            'status': self.status.value,
            'has_ventilator': self.has_ventilator,
            'has_monitor': self.has_monitor,
            'notes': self.notes,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
    
    @staticmethod
    def get_available_beds(bed_type=None, ward=None):
        """Get all available beds with optional filtering"""
        query = Bed.query.filter_by(status=BedStatus.AVAILABLE)
        
        if bed_type:
            query = query.filter_by(bed_type=bed_type)
        if ward:
            query = query.filter_by(ward=ward)
            
        return query.all()
    
    def set_occupied(self):
        """Mark bed as occupied"""
        self.status = BedStatus.OCCUPIED
        self.updated_at = datetime.utcnow()
        db.session.commit()
    
    def set_available(self):
        """Mark bed as available"""
        self.status = BedStatus.AVAILABLE
        self.updated_at = datetime.utcnow()
        db.session.commit() 