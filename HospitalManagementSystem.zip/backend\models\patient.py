from backend.app import db
from datetime import datetime, date
from enum import Enum
import uuid

class PatientStatus(Enum):
    ADMITTED = "Admitted"
    DISCHARGED = "Discharged"
    TRANSFERRED = "Transferred"
    DECEASED = "Deceased"

class Gender(Enum):
    MALE = "Male"
    FEMALE = "Female"
    OTHER = "Other"

class AdmissionType(Enum):
    EMERGENCY = "Emergency"
    SCHEDULED = "Scheduled"
    TRANSFER = "Transfer"

class Patient(db.Model):
    __tablename__ = 'patients'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    patient_id = db.Column(db.String(20), unique=True, nullable=False)
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    date_of_birth = db.Column(db.Date, nullable=False)
    gender = db.Column(db.Enum(Gender), nullable=False)
    phone = db.Column(db.String(20))
    email = db.Column(db.String(120))
    address = db.Column(db.Text)
    emergency_contact_name = db.Column(db.String(100))
    emergency_contact_phone = db.Column(db.String(20))
    medical_record_number = db.Column(db.String(20), unique=True)
    admission_date = db.Column(db.DateTime, nullable=False)
    admission_type = db.Column(db.Enum(AdmissionType), nullable=False)
    diagnosis = db.Column(db.Text)
    status = db.Column(db.Enum(PatientStatus), default=PatientStatus.ADMITTED, nullable=False)
    discharge_date = db.Column(db.DateTime)
    attending_physician = db.Column(db.String(100))
    insurance_info = db.Column(db.Text)
    allergies = db.Column(db.Text)
    medications = db.Column(db.Text)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    bed_allocations = db.relationship('BedAllocation', backref='patient', lazy=True)
    
    def __repr__(self):
        return f'<Patient {self.first_name} {self.last_name} - {self.patient_id}>'
    
    @property
    def full_name(self):
        return f"{self.first_name} {self.last_name}"
    
    @property
    def age(self):
        """Calculate age from date of birth"""
        today = date.today()
        return today.year - self.date_of_birth.year - ((today.month, today.day) < (self.date_of_birth.month, self.date_of_birth.day))
    
    @property
    def length_of_stay(self):
        """Calculate length of stay in days"""
        if self.status == PatientStatus.DISCHARGED and self.discharge_date:
            end_date = self.discharge_date
        else:
            end_date = datetime.utcnow()
        
        return (end_date - self.admission_date).days
    
    def to_dict(self):
        return {
            'id': self.id,
            'patient_id': self.patient_id,
            'first_name': self.first_name,
            'last_name': self.last_name,
            'full_name': self.full_name,
            'date_of_birth': self.date_of_birth.isoformat() if self.date_of_birth else None,
            'age': self.age,
            'gender': self.gender.value,
            'phone': self.phone,
            'email': self.email,
            'address': self.address,
            'emergency_contact_name': self.emergency_contact_name,
            'emergency_contact_phone': self.emergency_contact_phone,
            'medical_record_number': self.medical_record_number,
            'admission_date': self.admission_date.isoformat() if self.admission_date else None,
            'admission_type': self.admission_type.value,
            'diagnosis': self.diagnosis,
            'status': self.status.value,
            'discharge_date': self.discharge_date.isoformat() if self.discharge_date else None,
            'length_of_stay': self.length_of_stay,
            'attending_physician': self.attending_physician,
            'insurance_info': self.insurance_info,
            'allergies': self.allergies,
            'medications': self.medications,
            'notes': self.notes,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
    
    def discharge(self, discharge_date=None):
        """Discharge the patient"""
        self.status = PatientStatus.DISCHARGED
        self.discharge_date = discharge_date or datetime.utcnow()
        self.updated_at = datetime.utcnow()
        
        # Free up any allocated bed
        current_allocation = BedAllocation.query.filter_by(
            patient_id=self.id, 
            end_date=None
        ).first()
        
        if current_allocation:
            current_allocation.end_allocation()
        
        db.session.commit()
    
    @staticmethod
    def get_active_patients():
        """Get all currently admitted patients"""
        return Patient.query.filter_by(status=PatientStatus.ADMITTED).all() 