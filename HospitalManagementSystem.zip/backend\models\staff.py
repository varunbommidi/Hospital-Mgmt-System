from backend.app import db
from datetime import datetime, time
from enum import Enum
import uuid

class StaffRole(Enum):
    DOCTOR = "Doctor"
    NURSE = "Nurse"
    TECHNICIAN = "Technician"
    ADMINISTRATOR = "Administrator"
    SECURITY = "Security"
    CLEANER = "Cleaner"

class ShiftType(Enum):
    MORNING = "Morning"
    EVENING = "Evening"
    NIGHT = "Night"

class StaffStatus(Enum):
    ACTIVE = "Active"
    ON_LEAVE = "On Leave"
    SICK = "Sick"
    SUSPENDED = "Suspended"

class Staff(db.Model):
    __tablename__ = 'staff'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    employee_id = db.Column(db.String(20), unique=True, nullable=False)
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    phone = db.Column(db.String(20))
    role = db.Column(db.Enum(StaffRole), nullable=False)
    department = db.Column(db.String(100), nullable=False)
    specialization = db.Column(db.String(100))
    status = db.Column(db.Enum(StaffStatus), default=StaffStatus.ACTIVE, nullable=False)
    hire_date = db.Column(db.Date, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    schedules = db.relationship('StaffSchedule', backref='staff_member', lazy=True)
    allocations = db.relationship('StaffAllocation', foreign_keys='StaffAllocation.staff_id', backref='staff_member', lazy=True)
    
    def __repr__(self):
        return f'<Staff {self.first_name} {self.last_name} - {self.role.value}>'
    
    @property
    def full_name(self):
        return f"{self.first_name} {self.last_name}"
    
    def to_dict(self):
        return {
            'id': self.id,
            'employee_id': self.employee_id,
            'first_name': self.first_name,
            'last_name': self.last_name,
            'full_name': self.full_name,
            'email': self.email,
            'phone': self.phone,
            'role': self.role.value,
            'department': self.department,
            'specialization': self.specialization,
            'status': self.status.value,
            'hire_date': self.hire_date.isoformat() if self.hire_date else None,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class StaffSchedule(db.Model):
    __tablename__ = 'staff_schedules'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    staff_id = db.Column(db.String(36), db.ForeignKey('staff.id'), nullable=False)
    date = db.Column(db.Date, nullable=False)
    shift_type = db.Column(db.Enum(ShiftType), nullable=False)
    start_time = db.Column(db.Time, nullable=False)
    end_time = db.Column(db.Time, nullable=False)
    ward_assignment = db.Column(db.String(100))
    is_on_call = db.Column(db.Boolean, default=False)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<Schedule {self.staff_member.full_name} - {self.date} {self.shift_type.value}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'staff_id': self.staff_id,
            'staff_name': self.staff_member.full_name,
            'date': self.date.isoformat() if self.date else None,
            'shift_type': self.shift_type.value,
            'start_time': self.start_time.strftime('%H:%M') if self.start_time else None,
            'end_time': self.end_time.strftime('%H:%M') if self.end_time else None,
            'ward_assignment': self.ward_assignment,
            'is_on_call': self.is_on_call,
            'notes': self.notes,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
    
    @staticmethod
    def get_staff_for_shift(date, shift_type, ward=None):
        """Get all staff scheduled for a specific shift"""
        query = StaffSchedule.query.filter_by(date=date, shift_type=shift_type)
        
        if ward:
            query = query.filter_by(ward_assignment=ward)
            
        return query.all() 