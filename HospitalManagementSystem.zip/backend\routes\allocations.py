from flask import Blueprint, request, jsonify
from backend.app import db
from backend.models.allocation import BedAllocation, StaffAllocation, AllocationStatus
from backend.models.bed import Bed, BedStatus
from backend.models.staff import Staff, StaffStatus
from backend.models.patient import Patient, PatientStatus
from datetime import datetime
import uuid

allocations_bp = Blueprint('allocations', __name__)

@allocations_bp.route('/beds', methods=['GET'])
def get_bed_allocations():
    """Get all bed allocations with optional filtering"""
    try:
        # Get query parameters
        status = request.args.get('status')
        patient_id = request.args.get('patient_id')
        bed_id = request.args.get('bed_id')
        ward = request.args.get('ward')
        
        # Build query
        query = BedAllocation.query.join(Bed)
        
        if status:
            try:
                status_enum = AllocationStatus[status.upper()]
                query = query.filter(BedAllocation.status == status_enum)
            except KeyError:
                return jsonify({'error': 'Invalid status'}), 400
        if patient_id:
            query = query.filter(BedAllocation.patient_id == patient_id)
        if bed_id:
            query = query.filter(BedAllocation.bed_id == bed_id)
        if ward:
            query = query.filter(Bed.ward.ilike(f'%{ward}%'))
        
        allocations = query.order_by(BedAllocation.start_date.desc()).all()
        return jsonify([allocation.to_dict() for allocation in allocations])
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@allocations_bp.route('/staff', methods=['GET'])
def get_staff_allocations():
    """Get all staff allocations with optional filtering"""
    try:
        # Get query parameters
        status = request.args.get('status')
        staff_id = request.args.get('staff_id')
        ward = request.args.get('ward')
        patient_id = request.args.get('patient_id')
        
        # Build query
        query = StaffAllocation.query
        
        if status:
            try:
                status_enum = AllocationStatus[status.upper()]
                query = query.filter(StaffAllocation.status == status_enum)
            except KeyError:
                return jsonify({'error': 'Invalid status'}), 400
        if staff_id:
            query = query.filter(StaffAllocation.staff_id == staff_id)
        if ward:
            query = query.filter(StaffAllocation.ward.ilike(f'%{ward}%'))
        if patient_id:
            query = query.filter(StaffAllocation.patient_id == patient_id)
        
        allocations = query.order_by(StaffAllocation.start_date.desc()).all()
        return jsonify([allocation.to_dict() for allocation in allocations])
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@allocations_bp.route('/beds', methods=['POST'])
def allocate_bed():
    """Allocate a bed to a patient"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['bed_id', 'patient_id', 'allocated_by']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        # Validate that bed, patient, and allocator exist
        bed = Bed.query.get(data['bed_id'])
        if not bed:
            return jsonify({'error': 'Bed not found'}), 404
        
        patient = Patient.query.get(data['patient_id'])
        if not patient:
            return jsonify({'error': 'Patient not found'}), 404
        
        allocator = Staff.query.get(data['allocated_by'])
        if not allocator:
            return jsonify({'error': 'Allocator staff member not found'}), 404
        
        # Check if patient is admitted
        if patient.status != PatientStatus.ADMITTED:
            return jsonify({'error': 'Patient is not currently admitted'}), 400
        
        # Use the allocation method which includes validation
        allocation = BedAllocation.allocate_bed(
            bed_id=data['bed_id'],
            patient_id=data['patient_id'],
            allocated_by=data['allocated_by'],
            notes=data.get('notes')
        )
        
        return jsonify(allocation.to_dict()), 201
        
    except ValueError as e:
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@allocations_bp.route('/staff', methods=['POST'])
def allocate_staff():
    """Allocate staff to a ward or patient"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['staff_id', 'ward', 'allocated_by']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        # Validate that staff and allocator exist
        staff = Staff.query.get(data['staff_id'])
        if not staff:
            return jsonify({'error': 'Staff member not found'}), 404
        
        allocator = Staff.query.get(data['allocated_by'])
        if not allocator:
            return jsonify({'error': 'Allocator staff member not found'}), 404
        
        # Validate patient if provided
        patient_id = data.get('patient_id')
        if patient_id:
            patient = Patient.query.get(patient_id)
            if not patient:
                return jsonify({'error': 'Patient not found'}), 404
            if patient.status != PatientStatus.ADMITTED:
                return jsonify({'error': 'Patient is not currently admitted'}), 400
        
        # Use the allocation method which includes validation
        allocation = StaffAllocation.allocate_staff(
            staff_id=data['staff_id'],
            ward=data['ward'],
            allocated_by=data['allocated_by'],
            patient_id=patient_id,
            shift_type=data.get('shift_type'),
            priority=data.get('priority', 1),
            notes=data.get('notes')
        )
        
        return jsonify(allocation.to_dict()), 201
        
    except ValueError as e:
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@allocations_bp.route('/beds/<allocation_id>', methods=['PUT'])
def end_bed_allocation(allocation_id):
    """End a bed allocation"""
    try:
        allocation = BedAllocation.query.get(allocation_id)
        if not allocation:
            return jsonify({'error': 'Bed allocation not found'}), 404
        
        if allocation.status != AllocationStatus.ACTIVE:
            return jsonify({'error': 'Allocation is not active'}), 400
        
        data = request.get_json() or {}
        
        # Parse end_date if provided
        end_date = datetime.utcnow()
        if 'end_date' in data:
            try:
                end_date = datetime.strptime(data['end_date'], '%Y-%m-%d %H:%M:%S')
            except ValueError:
                try:
                    end_date = datetime.strptime(data['end_date'], '%Y-%m-%d')
                except ValueError:
                    return jsonify({'error': 'Invalid end_date format. Use YYYY-MM-DD or YYYY-MM-DD HH:MM:SS'}), 400
        
        allocation.end_allocation(end_date)
        
        return jsonify({
            'message': 'Bed allocation ended successfully',
            'allocation': allocation.to_dict()
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@allocations_bp.route('/staff/<allocation_id>', methods=['PUT'])
def end_staff_allocation(allocation_id):
    """End a staff allocation"""
    try:
        allocation = StaffAllocation.query.get(allocation_id)
        if not allocation:
            return jsonify({'error': 'Staff allocation not found'}), 404
        
        if allocation.status != AllocationStatus.ACTIVE:
            return jsonify({'error': 'Allocation is not active'}), 400
        
        data = request.get_json() or {}
        
        # Parse end_date if provided
        end_date = datetime.utcnow()
        if 'end_date' in data:
            try:
                end_date = datetime.strptime(data['end_date'], '%Y-%m-%d %H:%M:%S')
            except ValueError:
                try:
                    end_date = datetime.strptime(data['end_date'], '%Y-%m-%d')
                except ValueError:
                    return jsonify({'error': 'Invalid end_date format. Use YYYY-MM-DD or YYYY-MM-DD HH:MM:SS'}), 400
        
        allocation.end_allocation(end_date)
        
        return jsonify({
            'message': 'Staff allocation ended successfully',
            'allocation': allocation.to_dict()
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@allocations_bp.route('/recommend/bed', methods=['POST'])
def recommend_bed():
    """Recommend best bed for a patient based on requirements"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['patient_id']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        patient = Patient.query.get(data['patient_id'])
        if not patient:
            return jsonify({'error': 'Patient not found'}), 404
        
        # Get filtering criteria
        preferred_ward = data.get('ward')
        requires_ventilator = data.get('requires_ventilator', False)
        requires_monitor = data.get('requires_monitor', False)
        bed_type = data.get('bed_type')
        
        # Build query for available beds
        query = Bed.query.filter_by(status=BedStatus.AVAILABLE)
        
        # Apply filters
        if preferred_ward:
            query = query.filter(Bed.ward.ilike(f'%{preferred_ward}%'))
        if requires_ventilator:
            query = query.filter(Bed.has_ventilator == True)
        if requires_monitor:
            query = query.filter(Bed.has_monitor == True)
        if bed_type:
            from backend.models.bed import BedType
            try:
                bed_type_enum = BedType[bed_type.upper()]
                query = query.filter_by(bed_type=bed_type_enum)
            except KeyError:
                return jsonify({'error': 'Invalid bed type'}), 400
        
        available_beds = query.all()
        
        if not available_beds:
            return jsonify({
                'message': 'No beds available matching the criteria',
                'recommendations': []
            })
        
        # Score beds based on match criteria
        recommendations = []
        for bed in available_beds:
            score = 100  # Base score
            match_reasons = []
            
            # Exact ward match gets higher score
            if preferred_ward and preferred_ward.lower() in bed.ward.lower():
                score += 50
                match_reasons.append('Ward match')
            
            # Equipment matches
            if requires_ventilator and bed.has_ventilator:
                score += 30
                match_reasons.append('Has ventilator')
            elif requires_ventilator and not bed.has_ventilator:
                score -= 50
                
            if requires_monitor and bed.has_monitor:
                score += 20
                match_reasons.append('Has monitor')
            elif requires_monitor and not bed.has_monitor:
                score -= 30
            
            # Bed type match
            if bed_type and bed.bed_type.value.lower() == bed_type.lower():
                score += 40
                match_reasons.append('Bed type match')
            
            bed_data = bed.to_dict()
            bed_data['score'] = score
            bed_data['match_reasons'] = match_reasons
            recommendations.append(bed_data)
        
        # Sort by score descending
        recommendations.sort(key=lambda x: x['score'], reverse=True)
        
        return jsonify({
            'message': f'Found {len(recommendations)} bed recommendations',
            'recommendations': recommendations[:10]  # Return top 10
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@allocations_bp.route('/current', methods=['GET'])
def get_current_allocations():
    """Get current active allocations summary"""
    try:
        # Active bed allocations
        active_bed_allocations = BedAllocation.query.filter_by(status=AllocationStatus.ACTIVE).all()
        
        # Active staff allocations
        active_staff_allocations = StaffAllocation.query.filter_by(status=AllocationStatus.ACTIVE).all()
        
        return jsonify({
            'bed_allocations': {
                'count': len(active_bed_allocations),
                'allocations': [allocation.to_dict() for allocation in active_bed_allocations]
            },
            'staff_allocations': {
                'count': len(active_staff_allocations),
                'allocations': [allocation.to_dict() for allocation in active_staff_allocations]
            }
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500 