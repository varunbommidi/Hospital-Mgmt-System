from flask import Blueprint, request, jsonify
from backend.app import db
from backend.models.bed import Bed, BedType, BedStatus
from datetime import datetime
import uuid

beds_bp = Blueprint('beds', __name__)

@beds_bp.route('', methods=['GET'])
def get_beds():
    """Get all beds with optional filtering"""
    try:
        # Get query parameters
        ward = request.args.get('ward')
        bed_type = request.args.get('bed_type')
        status = request.args.get('status')
        floor = request.args.get('floor', type=int)
        
        # Build query
        query = Bed.query
        
        if ward:
            query = query.filter(Bed.ward.ilike(f'%{ward}%'))
        if bed_type:
            try:
                bed_type_enum = BedType[bed_type.upper()]
                query = query.filter_by(bed_type=bed_type_enum)
            except KeyError:
                return jsonify({'error': 'Invalid bed type'}), 400
        if status:
            try:
                status_enum = BedStatus[status.upper()]
                query = query.filter_by(status=status_enum)
            except KeyError:
                return jsonify({'error': 'Invalid status'}), 400
        if floor:
            query = query.filter_by(floor=floor)
        
        beds = query.all()
        return jsonify([bed.to_dict() for bed in beds])
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@beds_bp.route('/<bed_id>', methods=['GET'])
def get_bed(bed_id):
    """Get a specific bed by ID"""
    try:
        bed = Bed.query.get(bed_id)
        if not bed:
            return jsonify({'error': 'Bed not found'}), 404
        
        return jsonify(bed.to_dict())
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@beds_bp.route('', methods=['POST'])
def create_bed():
    """Create a new bed"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['bed_number', 'ward', 'floor', 'room_number', 'bed_type']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        # Validate bed_type
        try:
            bed_type = BedType[data['bed_type'].upper()]
        except KeyError:
            return jsonify({'error': 'Invalid bed type'}), 400
        
        # Check if bed number already exists
        existing_bed = Bed.query.filter_by(bed_number=data['bed_number']).first()
        if existing_bed:
            return jsonify({'error': 'Bed number already exists'}), 400
        
        # Create new bed
        bed = Bed(
            bed_number=data['bed_number'],
            ward=data['ward'],
            floor=data['floor'],
            room_number=data['room_number'],
            bed_type=bed_type,
            has_ventilator=data.get('has_ventilator', False),
            has_monitor=data.get('has_monitor', False),
            notes=data.get('notes')
        )
        
        db.session.add(bed)
        db.session.commit()
        
        return jsonify(bed.to_dict()), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@beds_bp.route('/<bed_id>', methods=['PUT'])
def update_bed(bed_id):
    """Update an existing bed"""
    try:
        bed = Bed.query.get(bed_id)
        if not bed:
            return jsonify({'error': 'Bed not found'}), 404
        
        data = request.get_json()
        
        # Update fields if provided
        if 'bed_number' in data:
            # Check if new bed number conflicts with existing
            existing_bed = Bed.query.filter(
                Bed.bed_number == data['bed_number'],
                Bed.id != bed_id
            ).first()
            if existing_bed:
                return jsonify({'error': 'Bed number already exists'}), 400
            bed.bed_number = data['bed_number']
            
        if 'ward' in data:
            bed.ward = data['ward']
        if 'floor' in data:
            bed.floor = data['floor']
        if 'room_number' in data:
            bed.room_number = data['room_number']
        if 'bed_type' in data:
            try:
                bed.bed_type = BedType[data['bed_type'].upper()]
            except KeyError:
                return jsonify({'error': 'Invalid bed type'}), 400
        if 'status' in data:
            try:
                bed.status = BedStatus[data['status'].upper()]
            except KeyError:
                return jsonify({'error': 'Invalid status'}), 400
        if 'has_ventilator' in data:
            bed.has_ventilator = data['has_ventilator']
        if 'has_monitor' in data:
            bed.has_monitor = data['has_monitor']
        if 'notes' in data:
            bed.notes = data['notes']
        
        bed.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify(bed.to_dict())
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@beds_bp.route('/<bed_id>', methods=['DELETE'])
def delete_bed(bed_id):
    """Delete a bed"""
    try:
        bed = Bed.query.get(bed_id)
        if not bed:
            return jsonify({'error': 'Bed not found'}), 404
        
        # Check if bed has active allocations
        from backend.models.allocation import BedAllocation, AllocationStatus
        active_allocation = BedAllocation.query.filter_by(
            bed_id=bed_id,
            status=AllocationStatus.ACTIVE
        ).first()
        
        if active_allocation:
            return jsonify({'error': 'Cannot delete bed with active allocation'}), 400
        
        db.session.delete(bed)
        db.session.commit()
        
        return jsonify({'message': 'Bed deleted successfully'})
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@beds_bp.route('/available', methods=['GET'])
def get_available_beds():
    """Get all available beds with optional filtering"""
    try:
        ward = request.args.get('ward')
        bed_type = request.args.get('bed_type')
        
        available_beds = Bed.get_available_beds(
            bed_type=BedType[bed_type.upper()] if bed_type else None,
            ward=ward
        )
        
        return jsonify([bed.to_dict() for bed in available_beds])
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@beds_bp.route('/statistics', methods=['GET'])
def get_bed_statistics():
    """Get bed statistics by ward, type, and status"""
    try:
        # Overall statistics
        total_beds = Bed.query.count()
        available_beds = Bed.query.filter_by(status=BedStatus.AVAILABLE).count()
        occupied_beds = Bed.query.filter_by(status=BedStatus.OCCUPIED).count()
        maintenance_beds = Bed.query.filter_by(status=BedStatus.MAINTENANCE).count()
        
        # Statistics by type
        stats_by_type = {}
        for bed_type in BedType:
            type_stats = {
                'total': Bed.query.filter_by(bed_type=bed_type).count(),
                'available': Bed.query.filter_by(bed_type=bed_type, status=BedStatus.AVAILABLE).count(),
                'occupied': Bed.query.filter_by(bed_type=bed_type, status=BedStatus.OCCUPIED).count(),
                'maintenance': Bed.query.filter_by(bed_type=bed_type, status=BedStatus.MAINTENANCE).count()
            }
            stats_by_type[bed_type.value] = type_stats
        
        # Statistics by ward
        wards = db.session.query(Bed.ward).distinct().all()
        stats_by_ward = {}
        for (ward,) in wards:
            ward_stats = {
                'total': Bed.query.filter_by(ward=ward).count(),
                'available': Bed.query.filter_by(ward=ward, status=BedStatus.AVAILABLE).count(),
                'occupied': Bed.query.filter_by(ward=ward, status=BedStatus.OCCUPIED).count(),
                'maintenance': Bed.query.filter_by(ward=ward, status=BedStatus.MAINTENANCE).count()
            }
            stats_by_ward[ward] = ward_stats
        
        return jsonify({
            'overall': {
                'total': total_beds,
                'available': available_beds,
                'occupied': occupied_beds,
                'maintenance': maintenance_beds,
                'occupancy_rate': round((occupied_beds / total_beds * 100) if total_beds > 0 else 0, 2)
            },
            'by_type': stats_by_type,
            'by_ward': stats_by_ward
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500 