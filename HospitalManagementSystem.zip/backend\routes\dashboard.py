from flask import Blueprint, request, jsonify
from backend.app import db
from backend.models.bed import Bed, BedStatus, BedType
from backend.models.staff import Staff, StaffStatus, StaffRole
from backend.models.patient import Patient, PatientStatus, AdmissionType
from backend.models.allocation import BedAllocation, StaffAllocation, AllocationStatus
from datetime import datetime, date, timedelta
from sqlalchemy import func

dashboard_bp = Blueprint('dashboard', __name__)

@dashboard_bp.route('/overview', methods=['GET'])
def get_dashboard_overview():
    """Get overall hospital statistics for dashboard"""
    try:
        # Bed statistics
        total_beds = Bed.query.count()
        available_beds = Bed.query.filter_by(status=BedStatus.AVAILABLE).count()
        occupied_beds = Bed.query.filter_by(status=BedStatus.OCCUPIED).count()
        maintenance_beds = Bed.query.filter_by(status=BedStatus.MAINTENANCE).count()
        occupancy_rate = round((occupied_beds / total_beds * 100) if total_beds > 0 else 0, 1)
        
        # Patient statistics
        total_patients = Patient.query.count()
        admitted_patients = Patient.query.filter_by(status=PatientStatus.ADMITTED).count()
        discharged_today = Patient.query.filter(
            Patient.status == PatientStatus.DISCHARGED,
            func.date(Patient.discharge_date) == date.today()
        ).count()
        admitted_today = Patient.query.filter(
            func.date(Patient.admission_date) == date.today()
        ).count()
        
        # Staff statistics
        total_staff = Staff.query.count()
        active_staff = Staff.query.filter_by(status=StaffStatus.ACTIVE).count()
        
        # Current allocations
        active_bed_allocations = BedAllocation.query.filter_by(status=AllocationStatus.ACTIVE).count()
        active_staff_allocations = StaffAllocation.query.filter_by(status=AllocationStatus.ACTIVE).count()
        
        # Emergency admissions today
        emergency_admissions_today = Patient.query.filter(
            Patient.admission_type == AdmissionType.EMERGENCY,
            func.date(Patient.admission_date) == date.today()
        ).count()
        
        return jsonify({
            'beds': {
                'total': total_beds,
                'available': available_beds,
                'occupied': occupied_beds,
                'maintenance': maintenance_beds,
                'occupancy_rate': occupancy_rate
            },
            'patients': {
                'total': total_patients,
                'admitted': admitted_patients,
                'admitted_today': admitted_today,
                'discharged_today': discharged_today,
                'emergency_admissions_today': emergency_admissions_today
            },
            'staff': {
                'total': total_staff,
                'active': active_staff
            },
            'allocations': {
                'active_bed_allocations': active_bed_allocations,
                'active_staff_allocations': active_staff_allocations
            }
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@dashboard_bp.route('/bed-occupancy', methods=['GET'])
def get_bed_occupancy_trends():
    """Get bed occupancy trends over time"""
    try:
        days = request.args.get('days', 7, type=int)
        
        # Calculate date range
        end_date = date.today()
        start_date = end_date - timedelta(days=days-1)
        
        trends = []
        current_date = start_date
        
        while current_date <= end_date:
            # Count beds occupied on this date
            occupied_on_date = BedAllocation.query.filter(
                BedAllocation.start_date <= datetime.combine(current_date, datetime.min.time()),
                (BedAllocation.end_date.is_(None)) | 
                (BedAllocation.end_date >= datetime.combine(current_date, datetime.max.time()))
            ).count()
            
            total_beds_on_date = Bed.query.count()  # Simplified - assumes beds don't change
            occupancy_rate = round((occupied_on_date / total_beds_on_date * 100) if total_beds_on_date > 0 else 0, 1)
            
            trends.append({
                'date': current_date.isoformat(),
                'occupied_beds': occupied_on_date,
                'total_beds': total_beds_on_date,
                'occupancy_rate': occupancy_rate
            })
            
            current_date += timedelta(days=1)
        
        return jsonify({
            'period': f'{days} days',
            'trends': trends
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@dashboard_bp.route('/ward-status', methods=['GET'])
def get_ward_status():
    """Get status breakdown by ward"""
    try:
        # Get all wards
        wards = db.session.query(Bed.ward).distinct().all()
        
        ward_status = []
        for (ward,) in wards:
            # Bed statistics for this ward
            total_beds = Bed.query.filter_by(ward=ward).count()
            available_beds = Bed.query.filter_by(ward=ward, status=BedStatus.AVAILABLE).count()
            occupied_beds = Bed.query.filter_by(ward=ward, status=BedStatus.OCCUPIED).count()
            maintenance_beds = Bed.query.filter_by(ward=ward, status=BedStatus.MAINTENANCE).count()
            
            # Patient count in this ward (through bed allocations)
            patients_in_ward = db.session.query(BedAllocation).join(Bed).filter(
                Bed.ward == ward,
                BedAllocation.status == AllocationStatus.ACTIVE
            ).count()
            
            # Staff allocated to this ward
            staff_in_ward = StaffAllocation.query.filter_by(
                ward=ward,
                status=AllocationStatus.ACTIVE
            ).count()
            
            occupancy_rate = round((occupied_beds / total_beds * 100) if total_beds > 0 else 0, 1)
            
            ward_status.append({
                'ward': ward,
                'beds': {
                    'total': total_beds,
                    'available': available_beds,
                    'occupied': occupied_beds,
                    'maintenance': maintenance_beds,
                    'occupancy_rate': occupancy_rate
                },
                'patients': patients_in_ward,
                'staff': staff_in_ward
            })
        
        return jsonify(ward_status)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@dashboard_bp.route('/admission-trends', methods=['GET'])
def get_admission_trends():
    """Get patient admission trends"""
    try:
        days = request.args.get('days', 30, type=int)
        
        # Calculate date range
        end_date = date.today()
        start_date = end_date - timedelta(days=days-1)
        
        trends = []
        current_date = start_date
        
        while current_date <= end_date:
            # Count admissions and discharges on this date
            admissions = Patient.query.filter(
                func.date(Patient.admission_date) == current_date
            ).count()
            
            discharges = Patient.query.filter(
                Patient.status == PatientStatus.DISCHARGED,
                func.date(Patient.discharge_date) == current_date
            ).count()
            
            emergency_admissions = Patient.query.filter(
                func.date(Patient.admission_date) == current_date,
                Patient.admission_type == AdmissionType.EMERGENCY
            ).count()
            
            trends.append({
                'date': current_date.isoformat(),
                'admissions': admissions,
                'discharges': discharges,
                'emergency_admissions': emergency_admissions,
                'net_change': admissions - discharges
            })
            
            current_date += timedelta(days=1)
        
        return jsonify({
            'period': f'{days} days',
            'trends': trends
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@dashboard_bp.route('/staff-utilization', methods=['GET'])
def get_staff_utilization():
    """Get staff utilization by role and department"""
    try:
        # Staff utilization by role
        utilization_by_role = []
        for role in StaffRole:
            total_staff = Staff.query.filter_by(role=role, status=StaffStatus.ACTIVE).count()
            allocated_staff = db.session.query(StaffAllocation.staff_id).filter(
                StaffAllocation.status == AllocationStatus.ACTIVE
            ).join(Staff).filter(Staff.role == role).distinct().count()
            
            utilization_rate = round((allocated_staff / total_staff * 100) if total_staff > 0 else 0, 1)
            
            utilization_by_role.append({
                'role': role.value,
                'total_staff': total_staff,
                'allocated_staff': allocated_staff,
                'utilization_rate': utilization_rate
            })
        
        # Staff utilization by department
        departments = db.session.query(Staff.department).distinct().all()
        utilization_by_department = []
        
        for (department,) in departments:
            total_staff = Staff.query.filter_by(department=department, status=StaffStatus.ACTIVE).count()
            allocated_staff = db.session.query(StaffAllocation.staff_id).filter(
                StaffAllocation.status == AllocationStatus.ACTIVE
            ).join(Staff).filter(Staff.department == department).distinct().count()
            
            utilization_rate = round((allocated_staff / total_staff * 100) if total_staff > 0 else 0, 1)
            
            utilization_by_department.append({
                'department': department,
                'total_staff': total_staff,
                'allocated_staff': allocated_staff,
                'utilization_rate': utilization_rate
            })
        
        return jsonify({
            'by_role': utilization_by_role,
            'by_department': utilization_by_department
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@dashboard_bp.route('/alerts', methods=['GET'])
def get_system_alerts():
    """Get system alerts and warnings"""
    try:
        alerts = []
        
        # High occupancy alert
        total_beds = Bed.query.count()
        occupied_beds = Bed.query.filter_by(status=BedStatus.OCCUPIED).count()
        occupancy_rate = (occupied_beds / total_beds * 100) if total_beds > 0 else 0
        
        if occupancy_rate > 90:
            alerts.append({
                'type': 'critical',
                'category': 'capacity',
                'message': f'Critical bed occupancy: {occupancy_rate:.1f}%',
                'action': 'Consider discharge planning or emergency bed management'
            })
        elif occupancy_rate > 80:
            alerts.append({
                'type': 'warning',
                'category': 'capacity',
                'message': f'High bed occupancy: {occupancy_rate:.1f}%',
                'action': 'Monitor capacity closely'
            })
        
        # Beds in maintenance
        maintenance_beds = Bed.query.filter_by(status=BedStatus.MAINTENANCE).count()
        if maintenance_beds > 0:
            alerts.append({
                'type': 'info',
                'category': 'maintenance',
                'message': f'{maintenance_beds} beds are under maintenance',
                'action': 'Check maintenance schedule'
            })
        
        # Staff allocation alerts
        unallocated_patients = Patient.query.outerjoin(BedAllocation).filter(
            Patient.status == PatientStatus.ADMITTED,
            BedAllocation.id.is_(None)
        ).count()
        
        if unallocated_patients > 0:
            alerts.append({
                'type': 'warning',
                'category': 'allocation',
                'message': f'{unallocated_patients} admitted patients without bed allocation',
                'action': 'Assign beds to patients'
            })
        
        # Emergency admissions today
        emergency_admissions_today = Patient.query.filter(
            Patient.admission_type == AdmissionType.EMERGENCY,
            func.date(Patient.admission_date) == date.today()
        ).count()
        
        if emergency_admissions_today > 10:  # Configurable threshold
            alerts.append({
                'type': 'warning',
                'category': 'admissions',
                'message': f'High emergency admissions today: {emergency_admissions_today}',
                'action': 'Monitor emergency department capacity'
            })
        
        return jsonify({
            'alerts': alerts,
            'count': len(alerts),
            'last_updated': datetime.utcnow().isoformat()
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@dashboard_bp.route('/recent-activity', methods=['GET'])
def get_recent_activity():
    """Get recent hospital activity"""
    try:
        limit = request.args.get('limit', 20, type=int)
        
        # Recent bed allocations
        recent_bed_allocations = BedAllocation.query.order_by(
            BedAllocation.created_at.desc()
        ).limit(limit//2).all()
        
        # Recent patient admissions
        recent_admissions = Patient.query.filter_by(
            status=PatientStatus.ADMITTED
        ).order_by(Patient.admission_date.desc()).limit(limit//2).all()
        
        activity = []
        
        # Add bed allocations to activity
        for allocation in recent_bed_allocations:
            activity.append({
                'type': 'bed_allocation',
                'timestamp': allocation.created_at.isoformat(),
                'description': f'Bed {allocation.bed.bed_number} allocated to {allocation.patient.full_name}',
                'details': {
                    'bed': allocation.bed.bed_number,
                    'ward': allocation.bed.ward,
                    'patient': allocation.patient.full_name,
                    'allocator': allocation.allocator.full_name if allocation.allocator else 'Unknown'
                }
            })
        
        # Add admissions to activity
        for patient in recent_admissions:
            activity.append({
                'type': 'patient_admission',
                'timestamp': patient.admission_date.isoformat(),
                'description': f'{patient.full_name} admitted ({patient.admission_type.value})',
                'details': {
                    'patient': patient.full_name,
                    'patient_id': patient.patient_id,
                    'admission_type': patient.admission_type.value,
                    'attending_physician': patient.attending_physician
                }
            })
        
        # Sort by timestamp descending
        activity.sort(key=lambda x: x['timestamp'], reverse=True)
        
        return jsonify({
            'activity': activity[:limit],
            'last_updated': datetime.utcnow().isoformat()
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500 