from flask import Blueprint, request, jsonify
from backend.app import db
from backend.models.patient import Patient, PatientStatus, Gender, AdmissionType
from datetime import datetime
import uuid

patients_bp = Blueprint('patients', __name__)

@patients_bp.route('', methods=['GET'])
def get_patients():
    """Get all patients with optional filtering"""
    try:
        # Get query parameters
        status = request.args.get('status')
        admission_type = request.args.get('admission_type')
        attending_physician = request.args.get('attending_physician')
        
        # Build query
        query = Patient.query
        
        if status:
            try:
                status_enum = PatientStatus[status.upper()]
                query = query.filter_by(status=status_enum)
            except KeyError:
                return jsonify({'error': 'Invalid status'}), 400
        if admission_type:
            try:
                admission_type_enum = AdmissionType[admission_type.upper()]
                query = query.filter_by(admission_type=admission_type_enum)
            except KeyError:
                return jsonify({'error': 'Invalid admission type'}), 400
        if attending_physician:
            query = query.filter(Patient.attending_physician.ilike(f'%{attending_physician}%'))
        
        patients = query.order_by(Patient.admission_date.desc()).all()
        return jsonify([patient.to_dict() for patient in patients])
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@patients_bp.route('/<patient_id>', methods=['GET'])
def get_patient(patient_id):
    """Get a specific patient by ID"""
    try:
        patient = Patient.query.get(patient_id)
        if not patient:
            return jsonify({'error': 'Patient not found'}), 404
        
        # Include current bed allocation if any
        from backend.models.allocation import BedAllocation, AllocationStatus
        current_allocation = BedAllocation.query.filter_by(
            patient_id=patient_id,
            status=AllocationStatus.ACTIVE
        ).first()
        
        patient_data = patient.to_dict()
        if current_allocation:
            patient_data['current_bed'] = current_allocation.to_dict()
        else:
            patient_data['current_bed'] = None
            
        return jsonify(patient_data)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@patients_bp.route('', methods=['POST'])
def create_patient():
    """Admit a new patient"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['patient_id', 'first_name', 'last_name', 'date_of_birth', 'gender', 'admission_type']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        # Validate enums
        try:
            gender = Gender[data['gender'].upper()]
            admission_type = AdmissionType[data['admission_type'].upper()]
        except KeyError as e:
            return jsonify({'error': f'Invalid enum value: {str(e)}'}), 400
        
        # Check if patient_id already exists
        existing_patient = Patient.query.filter_by(patient_id=data['patient_id']).first()
        if existing_patient:
            return jsonify({'error': 'Patient ID already exists'}), 400
        
        # Parse date_of_birth
        try:
            date_of_birth = datetime.strptime(data['date_of_birth'], '%Y-%m-%d').date()
        except ValueError:
            return jsonify({'error': 'Invalid date_of_birth format. Use YYYY-MM-DD'}), 400
        
        # Parse admission_date if provided, otherwise use current time
        admission_date = datetime.utcnow()
        if 'admission_date' in data:
            try:
                admission_date = datetime.strptime(data['admission_date'], '%Y-%m-%d %H:%M:%S')
            except ValueError:
                try:
                    admission_date = datetime.strptime(data['admission_date'], '%Y-%m-%d')
                except ValueError:
                    return jsonify({'error': 'Invalid admission_date format. Use YYYY-MM-DD or YYYY-MM-DD HH:MM:SS'}), 400
        
        # Create new patient
        patient = Patient(
            patient_id=data['patient_id'],
            first_name=data['first_name'],
            last_name=data['last_name'],
            date_of_birth=date_of_birth,
            gender=gender,
            phone=data.get('phone'),
            email=data.get('email'),
            address=data.get('address'),
            emergency_contact_name=data.get('emergency_contact_name'),
            emergency_contact_phone=data.get('emergency_contact_phone'),
            medical_record_number=data.get('medical_record_number'),
            admission_date=admission_date,
            admission_type=admission_type,
            diagnosis=data.get('diagnosis'),
            attending_physician=data.get('attending_physician'),
            insurance_info=data.get('insurance_info'),
            allergies=data.get('allergies'),
            medications=data.get('medications'),
            notes=data.get('notes')
        )
        
        db.session.add(patient)
        db.session.commit()
        
        return jsonify(patient.to_dict()), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@patients_bp.route('/<patient_id>', methods=['PUT'])
def update_patient(patient_id):
    """Update an existing patient"""
    try:
        patient = Patient.query.get(patient_id)
        if not patient:
            return jsonify({'error': 'Patient not found'}), 404
        
        data = request.get_json()
        
        # Update fields if provided
        if 'patient_id' in data:
            # Check if new patient_id conflicts with existing
            existing_patient = Patient.query.filter(
                Patient.patient_id == data['patient_id'],
                Patient.id != patient_id
            ).first()
            if existing_patient:
                return jsonify({'error': 'Patient ID already exists'}), 400
            patient.patient_id = data['patient_id']
            
        if 'first_name' in data:
            patient.first_name = data['first_name']
        if 'last_name' in data:
            patient.last_name = data['last_name']
        if 'date_of_birth' in data:
            try:
                patient.date_of_birth = datetime.strptime(data['date_of_birth'], '%Y-%m-%d').date()
            except ValueError:
                return jsonify({'error': 'Invalid date_of_birth format. Use YYYY-MM-DD'}), 400
        if 'gender' in data:
            try:
                patient.gender = Gender[data['gender'].upper()]
            except KeyError:
                return jsonify({'error': 'Invalid gender'}), 400
        if 'phone' in data:
            patient.phone = data['phone']
        if 'email' in data:
            patient.email = data['email']
        if 'address' in data:
            patient.address = data['address']
        if 'emergency_contact_name' in data:
            patient.emergency_contact_name = data['emergency_contact_name']
        if 'emergency_contact_phone' in data:
            patient.emergency_contact_phone = data['emergency_contact_phone']
        if 'medical_record_number' in data:
            patient.medical_record_number = data['medical_record_number']
        if 'diagnosis' in data:
            patient.diagnosis = data['diagnosis']
        if 'attending_physician' in data:
            patient.attending_physician = data['attending_physician']
        if 'insurance_info' in data:
            patient.insurance_info = data['insurance_info']
        if 'allergies' in data:
            patient.allergies = data['allergies']
        if 'medications' in data:
            patient.medications = data['medications']
        if 'notes' in data:
            patient.notes = data['notes']
        
        patient.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify(patient.to_dict())
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@patients_bp.route('/<patient_id>/discharge', methods=['POST'])
def discharge_patient(patient_id):
    """Discharge a patient"""
    try:
        patient = Patient.query.get(patient_id)
        if not patient:
            return jsonify({'error': 'Patient not found'}), 404
        
        if patient.status != PatientStatus.ADMITTED:
            return jsonify({'error': 'Patient is not currently admitted'}), 400
        
        data = request.get_json() or {}
        
        # Parse discharge_date if provided
        discharge_date = datetime.utcnow()
        if 'discharge_date' in data:
            try:
                discharge_date = datetime.strptime(data['discharge_date'], '%Y-%m-%d %H:%M:%S')
            except ValueError:
                try:
                    discharge_date = datetime.strptime(data['discharge_date'], '%Y-%m-%d')
                except ValueError:
                    return jsonify({'error': 'Invalid discharge_date format. Use YYYY-MM-DD or YYYY-MM-DD HH:MM:SS'}), 400
        
        # Discharge the patient (this will also handle bed deallocation)
        patient.discharge(discharge_date)
        
        return jsonify({
            'message': 'Patient discharged successfully',
            'patient': patient.to_dict()
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@patients_bp.route('/active', methods=['GET'])
def get_active_patients():
    """Get all currently admitted patients"""
    try:
        active_patients = Patient.get_active_patients()
        return jsonify([patient.to_dict() for patient in active_patients])
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@patients_bp.route('/search', methods=['GET'])
def search_patients():
    """Search patients by name, patient ID, or medical record number"""
    try:
        query_param = request.args.get('q', '').strip()
        if not query_param:
            return jsonify({'error': 'Search query parameter "q" is required'}), 400
        
        # Search in multiple fields
        patients = Patient.query.filter(
            (Patient.first_name.ilike(f'%{query_param}%')) |
            (Patient.last_name.ilike(f'%{query_param}%')) |
            (Patient.patient_id.ilike(f'%{query_param}%')) |
            (Patient.medical_record_number.ilike(f'%{query_param}%'))
        ).limit(20).all()
        
        return jsonify([patient.to_dict() for patient in patients])
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@patients_bp.route('/statistics', methods=['GET'])
def get_patient_statistics():
    """Get patient statistics"""
    try:
        # Overall statistics
        total_patients = Patient.query.count()
        admitted_patients = Patient.query.filter_by(status=PatientStatus.ADMITTED).count()
        discharged_patients = Patient.query.filter_by(status=PatientStatus.DISCHARGED).count()
        
        # Statistics by admission type
        stats_by_admission_type = {}
        for admission_type in AdmissionType:
            type_stats = {
                'total': Patient.query.filter_by(admission_type=admission_type).count(),
                'admitted': Patient.query.filter_by(admission_type=admission_type, status=PatientStatus.ADMITTED).count()
            }
            stats_by_admission_type[admission_type.value] = type_stats
        
        # Statistics by gender
        stats_by_gender = {}
        for gender in Gender:
            gender_stats = {
                'total': Patient.query.filter_by(gender=gender).count(),
                'admitted': Patient.query.filter_by(gender=gender, status=PatientStatus.ADMITTED).count()
            }
            stats_by_gender[gender.value] = gender_stats
        
        # Average length of stay for discharged patients
        discharged_with_los = Patient.query.filter(
            Patient.status == PatientStatus.DISCHARGED,
            Patient.discharge_date.isnot(None)
        ).all()
        
        avg_length_of_stay = 0
        if discharged_with_los:
            total_los = sum([p.length_of_stay for p in discharged_with_los])
            avg_length_of_stay = round(total_los / len(discharged_with_los), 1)
        
        return jsonify({
            'overall': {
                'total': total_patients,
                'admitted': admitted_patients,
                'discharged': discharged_patients,
                'average_length_of_stay': avg_length_of_stay
            },
            'by_admission_type': stats_by_admission_type,
            'by_gender': stats_by_gender
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500 