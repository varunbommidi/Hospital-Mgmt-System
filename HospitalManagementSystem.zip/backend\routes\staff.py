from flask import Blueprint, request, jsonify
from backend.app import db
from backend.models.staff import Staff, StaffSchedule, StaffRole, StaffStatus, ShiftType
from datetime import datetime, date, time
import uuid

staff_bp = Blueprint('staff', __name__)

@staff_bp.route('', methods=['GET'])
def get_staff():
    """Get all staff with optional filtering"""
    try:
        # Get query parameters
        role = request.args.get('role')
        department = request.args.get('department')
        status = request.args.get('status')
        
        # Build query
        query = Staff.query
        
        if role:
            try:
                role_enum = StaffRole[role.upper()]
                query = query.filter_by(role=role_enum)
            except KeyError:
                return jsonify({'error': 'Invalid role'}), 400
        if department:
            query = query.filter(Staff.department.ilike(f'%{department}%'))
        if status:
            try:
                status_enum = StaffStatus[status.upper().replace(' ', '_')]
                query = query.filter_by(status=status_enum)
            except KeyError:
                return jsonify({'error': 'Invalid status'}), 400
        
        staff_list = query.all()
        return jsonify([staff.to_dict() for staff in staff_list])
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@staff_bp.route('/<staff_id>', methods=['GET'])
def get_staff_member(staff_id):
    """Get a specific staff member by ID"""
    try:
        staff = Staff.query.get(staff_id)
        if not staff:
            return jsonify({'error': 'Staff member not found'}), 404
        
        return jsonify(staff.to_dict())
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@staff_bp.route('', methods=['POST'])
def create_staff():
    """Create a new staff member"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['employee_id', 'first_name', 'last_name', 'email', 'role', 'department', 'hire_date']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        # Validate role
        try:
            role = StaffRole[data['role'].upper()]
        except KeyError:
            return jsonify({'error': 'Invalid role'}), 400
        
        # Check if employee_id or email already exists
        existing_staff = Staff.query.filter(
            (Staff.employee_id == data['employee_id']) | 
            (Staff.email == data['email'])
        ).first()
        if existing_staff:
            return jsonify({'error': 'Employee ID or email already exists'}), 400
        
        # Parse hire_date
        try:
            hire_date = datetime.strptime(data['hire_date'], '%Y-%m-%d').date()
        except ValueError:
            return jsonify({'error': 'Invalid hire_date format. Use YYYY-MM-DD'}), 400
        
        # Create new staff member
        staff = Staff(
            employee_id=data['employee_id'],
            first_name=data['first_name'],
            last_name=data['last_name'],
            email=data['email'],
            phone=data.get('phone'),
            role=role,
            department=data['department'],
            specialization=data.get('specialization'),
            hire_date=hire_date
        )
        
        db.session.add(staff)
        db.session.commit()
        
        return jsonify(staff.to_dict()), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@staff_bp.route('/<staff_id>', methods=['PUT'])
def update_staff(staff_id):
    """Update an existing staff member"""
    try:
        staff = Staff.query.get(staff_id)
        if not staff:
            return jsonify({'error': 'Staff member not found'}), 404
        
        data = request.get_json()
        
        # Update fields if provided
        if 'employee_id' in data:
            # Check if new employee_id conflicts with existing
            existing_staff = Staff.query.filter(
                Staff.employee_id == data['employee_id'],
                Staff.id != staff_id
            ).first()
            if existing_staff:
                return jsonify({'error': 'Employee ID already exists'}), 400
            staff.employee_id = data['employee_id']
            
        if 'email' in data:
            # Check if new email conflicts with existing
            existing_staff = Staff.query.filter(
                Staff.email == data['email'],
                Staff.id != staff_id
            ).first()
            if existing_staff:
                return jsonify({'error': 'Email already exists'}), 400
            staff.email = data['email']
            
        if 'first_name' in data:
            staff.first_name = data['first_name']
        if 'last_name' in data:
            staff.last_name = data['last_name']
        if 'phone' in data:
            staff.phone = data['phone']
        if 'role' in data:
            try:
                staff.role = StaffRole[data['role'].upper()]
            except KeyError:
                return jsonify({'error': 'Invalid role'}), 400
        if 'department' in data:
            staff.department = data['department']
        if 'specialization' in data:
            staff.specialization = data['specialization']
        if 'status' in data:
            try:
                staff.status = StaffStatus[data['status'].upper().replace(' ', '_')]
            except KeyError:
                return jsonify({'error': 'Invalid status'}), 400
        if 'hire_date' in data:
            try:
                staff.hire_date = datetime.strptime(data['hire_date'], '%Y-%m-%d').date()
            except ValueError:
                return jsonify({'error': 'Invalid hire_date format. Use YYYY-MM-DD'}), 400
        
        staff.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify(staff.to_dict())
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@staff_bp.route('/<staff_id>/schedule', methods=['GET'])
def get_staff_schedule(staff_id):
    """Get schedule for a specific staff member"""
    try:
        staff = Staff.query.get(staff_id)
        if not staff:
            return jsonify({'error': 'Staff member not found'}), 404
        
        # Get date range from query parameters
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        
        query = StaffSchedule.query.filter_by(staff_id=staff_id)
        
        if start_date:
            try:
                start_date = datetime.strptime(start_date, '%Y-%m-%d').date()
                query = query.filter(StaffSchedule.date >= start_date)
            except ValueError:
                return jsonify({'error': 'Invalid start_date format. Use YYYY-MM-DD'}), 400
                
        if end_date:
            try:
                end_date = datetime.strptime(end_date, '%Y-%m-%d').date()
                query = query.filter(StaffSchedule.date <= end_date)
            except ValueError:
                return jsonify({'error': 'Invalid end_date format. Use YYYY-MM-DD'}), 400
        
        schedules = query.order_by(StaffSchedule.date).all()
        return jsonify([schedule.to_dict() for schedule in schedules])
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@staff_bp.route('/<staff_id>/schedule', methods=['POST'])
def create_staff_schedule(staff_id):
    """Create a new schedule entry for a staff member"""
    try:
        staff = Staff.query.get(staff_id)
        if not staff:
            return jsonify({'error': 'Staff member not found'}), 404
        
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['date', 'shift_type', 'start_time', 'end_time']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        # Parse and validate data
        try:
            schedule_date = datetime.strptime(data['date'], '%Y-%m-%d').date()
            shift_type = ShiftType[data['shift_type'].upper()]
            start_time = datetime.strptime(data['start_time'], '%H:%M').time()
            end_time = datetime.strptime(data['end_time'], '%H:%M').time()
        except ValueError as e:
            return jsonify({'error': f'Invalid data format: {str(e)}'}), 400
        except KeyError:
            return jsonify({'error': 'Invalid shift_type'}), 400
        
        # Check for existing schedule on the same date
        existing_schedule = StaffSchedule.query.filter_by(
            staff_id=staff_id,
            date=schedule_date
        ).first()
        
        if existing_schedule:
            return jsonify({'error': 'Staff member already has a schedule for this date'}), 400
        
        # Create new schedule
        schedule = StaffSchedule(
            staff_id=staff_id,
            date=schedule_date,
            shift_type=shift_type,
            start_time=start_time,
            end_time=end_time,
            ward_assignment=data.get('ward_assignment'),
            is_on_call=data.get('is_on_call', False),
            notes=data.get('notes')
        )
        
        db.session.add(schedule)
        db.session.commit()
        
        return jsonify(schedule.to_dict()), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@staff_bp.route('/available', methods=['GET'])
def get_available_staff():
    """Get available staff for a specific date and shift"""
    try:
        date_str = request.args.get('date')
        shift_type_str = request.args.get('shift_type')
        role_str = request.args.get('role')
        ward = request.args.get('ward')
        
        if not date_str:
            return jsonify({'error': 'Date parameter is required'}), 400
        
        try:
            query_date = datetime.strptime(date_str, '%Y-%m-%d').date()
        except ValueError:
            return jsonify({'error': 'Invalid date format. Use YYYY-MM-DD'}), 400
        
        # Get staff who are scheduled for the specific date/shift
        query = StaffSchedule.query.filter_by(date=query_date)
        
        if shift_type_str:
            try:
                shift_type = ShiftType[shift_type_str.upper()]
                query = query.filter_by(shift_type=shift_type)
            except KeyError:
                return jsonify({'error': 'Invalid shift_type'}), 400
        
        if ward:
            query = query.filter_by(ward_assignment=ward)
        
        scheduled_staff = query.all()
        
        # Filter by role if specified
        if role_str:
            try:
                role = StaffRole[role_str.upper()]
                scheduled_staff = [s for s in scheduled_staff if s.staff_member.role == role]
            except KeyError:
                return jsonify({'error': 'Invalid role'}), 400
        
        return jsonify([{
            'schedule': schedule.to_dict(),
            'staff': schedule.staff_member.to_dict()
        } for schedule in scheduled_staff])
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@staff_bp.route('/statistics', methods=['GET'])
def get_staff_statistics():
    """Get staff statistics by role, department, and status"""
    try:
        # Overall statistics
        total_staff = Staff.query.count()
        active_staff = Staff.query.filter_by(status=StaffStatus.ACTIVE).count()
        
        # Statistics by role
        stats_by_role = {}
        for role in StaffRole:
            role_stats = {
                'total': Staff.query.filter_by(role=role).count(),
                'active': Staff.query.filter_by(role=role, status=StaffStatus.ACTIVE).count()
            }
            stats_by_role[role.value] = role_stats
        
        # Statistics by department
        departments = db.session.query(Staff.department).distinct().all()
        stats_by_department = {}
        for (department,) in departments:
            dept_stats = {
                'total': Staff.query.filter_by(department=department).count(),
                'active': Staff.query.filter_by(department=department, status=StaffStatus.ACTIVE).count()
            }
            stats_by_department[department] = dept_stats
        
        return jsonify({
            'overall': {
                'total': total_staff,
                'active': active_staff
            },
            'by_role': stats_by_role,
            'by_department': stats_by_department
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500 