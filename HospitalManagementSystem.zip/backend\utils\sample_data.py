from backend.app import db
from backend.models.bed import Bed, BedType, BedStatus
from backend.models.staff import Staff, StaffRole, StaffStatus, StaffSchedule, ShiftType
from backend.models.patient import Patient, PatientStatus, Gender, AdmissionType
from backend.models.allocation import BedAllocation, StaffAllocation
from datetime import datetime, date, time, timedelta
import random

def initialize_sample_data(force=False):
    """Initialize the database with comprehensive sample data for testing"""
    
    # Check if data already exists
    if Bed.query.count() > 0 and not force:
        return  # Data already exists
    
    try:
        # Comprehensive Beds Data - 50+ beds across multiple wards
        beds_data = [
            # ICU Ward (15 beds)
            {'bed_number': 'ICU-001', 'ward': 'ICU', 'floor': 2, 'room_number': '201', 'bed_type': BedType.ICU, 'has_ventilator': True, 'has_monitor': True},
            {'bed_number': 'ICU-002', 'ward': 'ICU', 'floor': 2, 'room_number': '201', 'bed_type': BedType.ICU, 'has_ventilator': True, 'has_monitor': True},
            {'bed_number': 'ICU-003', 'ward': 'ICU', 'floor': 2, 'room_number': '202', 'bed_type': BedType.ICU, 'has_ventilator': True, 'has_monitor': True},
            {'bed_number': 'ICU-004', 'ward': 'ICU', 'floor': 2, 'room_number': '202', 'bed_type': BedType.ICU, 'has_ventilator': True, 'has_monitor': True},
            {'bed_number': 'ICU-005', 'ward': 'ICU', 'floor': 2, 'room_number': '203', 'bed_type': BedType.ICU, 'has_ventilator': False, 'has_monitor': True},
            {'bed_number': 'ICU-006', 'ward': 'ICU', 'floor': 2, 'room_number': '203', 'bed_type': BedType.ICU, 'has_ventilator': True, 'has_monitor': True},
            {'bed_number': 'ICU-007', 'ward': 'ICU', 'floor': 2, 'room_number': '204', 'bed_type': BedType.ICU, 'has_ventilator': True, 'has_monitor': True},
            {'bed_number': 'ICU-008', 'ward': 'ICU', 'floor': 2, 'room_number': '204', 'bed_type': BedType.ICU, 'has_ventilator': True, 'has_monitor': True},
            {'bed_number': 'ICU-009', 'ward': 'ICU', 'floor': 2, 'room_number': '205', 'bed_type': BedType.ICU, 'has_ventilator': False, 'has_monitor': True},
            {'bed_number': 'ICU-010', 'ward': 'ICU', 'floor': 2, 'room_number': '205', 'bed_type': BedType.ICU, 'has_ventilator': True, 'has_monitor': True},
            {'bed_number': 'ICU-011', 'ward': 'ICU', 'floor': 2, 'room_number': '206', 'bed_type': BedType.ICU, 'has_ventilator': True, 'has_monitor': True},
            {'bed_number': 'ICU-012', 'ward': 'ICU', 'floor': 2, 'room_number': '206', 'bed_type': BedType.ICU, 'has_ventilator': True, 'has_monitor': True},
            {'bed_number': 'ICU-013', 'ward': 'ICU', 'floor': 2, 'room_number': '207', 'bed_type': BedType.ICU, 'has_ventilator': False, 'has_monitor': True},
            {'bed_number': 'ICU-014', 'ward': 'ICU', 'floor': 2, 'room_number': '207', 'bed_type': BedType.ICU, 'has_ventilator': True, 'has_monitor': True},
            {'bed_number': 'ICU-015', 'ward': 'ICU', 'floor': 2, 'room_number': '208', 'bed_type': BedType.ICU, 'has_ventilator': True, 'has_monitor': True},
            
            # General Medicine Ward (20 beds)
            {'bed_number': 'GEN-001', 'ward': 'General Medicine', 'floor': 3, 'room_number': '301', 'bed_type': BedType.GENERAL, 'has_ventilator': False, 'has_monitor': True},
            {'bed_number': 'GEN-002', 'ward': 'General Medicine', 'floor': 3, 'room_number': '301', 'bed_type': BedType.GENERAL, 'has_ventilator': False, 'has_monitor': True},
            {'bed_number': 'GEN-003', 'ward': 'General Medicine', 'floor': 3, 'room_number': '302', 'bed_type': BedType.GENERAL, 'has_ventilator': False, 'has_monitor': False},
            {'bed_number': 'GEN-004', 'ward': 'General Medicine', 'floor': 3, 'room_number': '302', 'bed_type': BedType.GENERAL, 'has_ventilator': False, 'has_monitor': False},
            {'bed_number': 'GEN-005', 'ward': 'General Medicine', 'floor': 3, 'room_number': '303', 'bed_type': BedType.GENERAL, 'has_ventilator': False, 'has_monitor': True},
            {'bed_number': 'GEN-006', 'ward': 'General Medicine', 'floor': 3, 'room_number': '303', 'bed_type': BedType.GENERAL, 'has_ventilator': False, 'has_monitor': True},
            {'bed_number': 'GEN-007', 'ward': 'General Medicine', 'floor': 3, 'room_number': '304', 'bed_type': BedType.GENERAL, 'has_ventilator': False, 'has_monitor': False},
            {'bed_number': 'GEN-008', 'ward': 'General Medicine', 'floor': 3, 'room_number': '304', 'bed_type': BedType.GENERAL, 'has_ventilator': False, 'has_monitor': False},
            {'bed_number': 'GEN-009', 'ward': 'General Medicine', 'floor': 3, 'room_number': '305', 'bed_type': BedType.GENERAL, 'has_ventilator': False, 'has_monitor': True},
            {'bed_number': 'GEN-010', 'ward': 'General Medicine', 'floor': 3, 'room_number': '305', 'bed_type': BedType.GENERAL, 'has_ventilator': False, 'has_monitor': True},
            {'bed_number': 'GEN-011', 'ward': 'General Medicine', 'floor': 3, 'room_number': '306', 'bed_type': BedType.GENERAL, 'has_ventilator': False, 'has_monitor': False},
            {'bed_number': 'GEN-012', 'ward': 'General Medicine', 'floor': 3, 'room_number': '306', 'bed_type': BedType.GENERAL, 'has_ventilator': False, 'has_monitor': False},
            {'bed_number': 'GEN-013', 'ward': 'General Medicine', 'floor': 3, 'room_number': '307', 'bed_type': BedType.GENERAL, 'has_ventilator': False, 'has_monitor': True},
            {'bed_number': 'GEN-014', 'ward': 'General Medicine', 'floor': 3, 'room_number': '307', 'bed_type': BedType.GENERAL, 'has_ventilator': False, 'has_monitor': True},
            {'bed_number': 'GEN-015', 'ward': 'General Medicine', 'floor': 3, 'room_number': '308', 'bed_type': BedType.GENERAL, 'has_ventilator': False, 'has_monitor': False},
            {'bed_number': 'GEN-016', 'ward': 'General Medicine', 'floor': 3, 'room_number': '308', 'bed_type': BedType.GENERAL, 'has_ventilator': False, 'has_monitor': False},
            {'bed_number': 'GEN-017', 'ward': 'General Medicine', 'floor': 3, 'room_number': '309', 'bed_type': BedType.GENERAL, 'has_ventilator': False, 'has_monitor': True},
            {'bed_number': 'GEN-018', 'ward': 'General Medicine', 'floor': 3, 'room_number': '309', 'bed_type': BedType.GENERAL, 'has_ventilator': False, 'has_monitor': True},
            {'bed_number': 'GEN-019', 'ward': 'General Medicine', 'floor': 3, 'room_number': '310', 'bed_type': BedType.GENERAL, 'has_ventilator': False, 'has_monitor': False},
            {'bed_number': 'GEN-020', 'ward': 'General Medicine', 'floor': 3, 'room_number': '310', 'bed_type': BedType.GENERAL, 'has_ventilator': False, 'has_monitor': False},
            
            # Emergency Ward (8 beds)
            {'bed_number': 'ER-001', 'ward': 'Emergency', 'floor': 1, 'room_number': '101', 'bed_type': BedType.EMERGENCY, 'has_ventilator': True, 'has_monitor': True},
            {'bed_number': 'ER-002', 'ward': 'Emergency', 'floor': 1, 'room_number': '101', 'bed_type': BedType.EMERGENCY, 'has_ventilator': False, 'has_monitor': True},
            {'bed_number': 'ER-003', 'ward': 'Emergency', 'floor': 1, 'room_number': '102', 'bed_type': BedType.EMERGENCY, 'has_ventilator': False, 'has_monitor': True},
            {'bed_number': 'ER-004', 'ward': 'Emergency', 'floor': 1, 'room_number': '102', 'bed_type': BedType.EMERGENCY, 'has_ventilator': True, 'has_monitor': True},
            {'bed_number': 'ER-005', 'ward': 'Emergency', 'floor': 1, 'room_number': '103', 'bed_type': BedType.EMERGENCY, 'has_ventilator': False, 'has_monitor': True},
            {'bed_number': 'ER-006', 'ward': 'Emergency', 'floor': 1, 'room_number': '103', 'bed_type': BedType.EMERGENCY, 'has_ventilator': False, 'has_monitor': True},
            {'bed_number': 'ER-007', 'ward': 'Emergency', 'floor': 1, 'room_number': '104', 'bed_type': BedType.EMERGENCY, 'has_ventilator': True, 'has_monitor': True},
            {'bed_number': 'ER-008', 'ward': 'Emergency', 'floor': 1, 'room_number': '104', 'bed_type': BedType.EMERGENCY, 'has_ventilator': False, 'has_monitor': True},
            
            # Pediatric Ward (8 beds)
            {'bed_number': 'PED-001', 'ward': 'Pediatrics', 'floor': 4, 'room_number': '401', 'bed_type': BedType.PEDIATRIC, 'has_ventilator': False, 'has_monitor': True},
            {'bed_number': 'PED-002', 'ward': 'Pediatrics', 'floor': 4, 'room_number': '401', 'bed_type': BedType.PEDIATRIC, 'has_ventilator': False, 'has_monitor': True},
            {'bed_number': 'PED-003', 'ward': 'Pediatrics', 'floor': 4, 'room_number': '402', 'bed_type': BedType.PEDIATRIC, 'has_ventilator': False, 'has_monitor': False},
            {'bed_number': 'PED-004', 'ward': 'Pediatrics', 'floor': 4, 'room_number': '402', 'bed_type': BedType.PEDIATRIC, 'has_ventilator': False, 'has_monitor': False},
            {'bed_number': 'PED-005', 'ward': 'Pediatrics', 'floor': 4, 'room_number': '403', 'bed_type': BedType.PEDIATRIC, 'has_ventilator': False, 'has_monitor': True},
            {'bed_number': 'PED-006', 'ward': 'Pediatrics', 'floor': 4, 'room_number': '403', 'bed_type': BedType.PEDIATRIC, 'has_ventilator': False, 'has_monitor': True},
            {'bed_number': 'PED-007', 'ward': 'Pediatrics', 'floor': 4, 'room_number': '404', 'bed_type': BedType.PEDIATRIC, 'has_ventilator': False, 'has_monitor': False},
            {'bed_number': 'PED-008', 'ward': 'Pediatrics', 'floor': 4, 'room_number': '404', 'bed_type': BedType.PEDIATRIC, 'has_ventilator': False, 'has_monitor': False},
            
            # Surgery Ward (10 beds)
            {'bed_number': 'SUR-001', 'ward': 'Surgery', 'floor': 5, 'room_number': '501', 'bed_type': BedType.SURGERY, 'has_ventilator': False, 'has_monitor': True},
            {'bed_number': 'SUR-002', 'ward': 'Surgery', 'floor': 5, 'room_number': '501', 'bed_type': BedType.SURGERY, 'has_ventilator': False, 'has_monitor': True},
            {'bed_number': 'SUR-003', 'ward': 'Surgery', 'floor': 5, 'room_number': '502', 'bed_type': BedType.SURGERY, 'has_ventilator': False, 'has_monitor': True},
            {'bed_number': 'SUR-004', 'ward': 'Surgery', 'floor': 5, 'room_number': '502', 'bed_type': BedType.SURGERY, 'has_ventilator': False, 'has_monitor': True},
            {'bed_number': 'SUR-005', 'ward': 'Surgery', 'floor': 5, 'room_number': '503', 'bed_type': BedType.SURGERY, 'has_ventilator': False, 'has_monitor': True},
            {'bed_number': 'SUR-006', 'ward': 'Surgery', 'floor': 5, 'room_number': '503', 'bed_type': BedType.SURGERY, 'has_ventilator': False, 'has_monitor': True},
            {'bed_number': 'SUR-007', 'ward': 'Surgery', 'floor': 5, 'room_number': '504', 'bed_type': BedType.SURGERY, 'has_ventilator': False, 'has_monitor': True},
            {'bed_number': 'SUR-008', 'ward': 'Surgery', 'floor': 5, 'room_number': '504', 'bed_type': BedType.SURGERY, 'has_ventilator': False, 'has_monitor': True},
            {'bed_number': 'SUR-009', 'ward': 'Surgery', 'floor': 5, 'room_number': '505', 'bed_type': BedType.SURGERY, 'has_ventilator': False, 'has_monitor': True},
            {'bed_number': 'SUR-010', 'ward': 'Surgery', 'floor': 5, 'room_number': '505', 'bed_type': BedType.SURGERY, 'has_ventilator': False, 'has_monitor': True},
            
            # Maternity Ward (6 beds)
            {'bed_number': 'MAT-001', 'ward': 'Maternity', 'floor': 4, 'room_number': '410', 'bed_type': BedType.MATERNITY, 'has_ventilator': False, 'has_monitor': True},
            {'bed_number': 'MAT-002', 'ward': 'Maternity', 'floor': 4, 'room_number': '410', 'bed_type': BedType.MATERNITY, 'has_ventilator': False, 'has_monitor': True},
            {'bed_number': 'MAT-003', 'ward': 'Maternity', 'floor': 4, 'room_number': '411', 'bed_type': BedType.MATERNITY, 'has_ventilator': False, 'has_monitor': True},
            {'bed_number': 'MAT-004', 'ward': 'Maternity', 'floor': 4, 'room_number': '411', 'bed_type': BedType.MATERNITY, 'has_ventilator': False, 'has_monitor': True},
            {'bed_number': 'MAT-005', 'ward': 'Maternity', 'floor': 4, 'room_number': '412', 'bed_type': BedType.MATERNITY, 'has_ventilator': False, 'has_monitor': True},
            {'bed_number': 'MAT-006', 'ward': 'Maternity', 'floor': 4, 'room_number': '412', 'bed_type': BedType.MATERNITY, 'has_ventilator': False, 'has_monitor': True},
        ]
        
        for bed_data in beds_data:
            bed = Bed(**bed_data)
            db.session.add(bed)
        
        # Comprehensive Staff Data - 35+ staff members
        staff_data = [
            # Doctors (15 doctors)
            {'employee_id': 'DOC001', 'first_name': 'John', 'last_name': 'Smith', 'email': 'john.smith@hospital.com', 'phone': '555-0101', 'role': StaffRole.DOCTOR, 'department': 'Emergency Medicine', 'specialization': 'Emergency Medicine', 'hire_date': date(2020, 1, 15)},
            {'employee_id': 'DOC002', 'first_name': 'Sarah', 'last_name': 'Johnson', 'email': 'sarah.johnson@hospital.com', 'phone': '555-0102', 'role': StaffRole.DOCTOR, 'department': 'Internal Medicine', 'specialization': 'Cardiology', 'hire_date': date(2019, 3, 20)},
            {'employee_id': 'DOC003', 'first_name': 'Michael', 'last_name': 'Brown', 'email': 'michael.brown@hospital.com', 'phone': '555-0103', 'role': StaffRole.DOCTOR, 'department': 'Surgery', 'specialization': 'General Surgery', 'hire_date': date(2018, 6, 10)},
            {'employee_id': 'DOC004', 'first_name': 'Emily', 'last_name': 'Davis', 'email': 'emily.davis@hospital.com', 'phone': '555-0104', 'role': StaffRole.DOCTOR, 'department': 'Pediatrics', 'specialization': 'Pediatric Medicine', 'hire_date': date(2021, 2, 28)},
            {'employee_id': 'DOC005', 'first_name': 'David', 'last_name': 'Wilson', 'email': 'david.wilson@hospital.com', 'phone': '555-0105', 'role': StaffRole.DOCTOR, 'department': 'ICU', 'specialization': 'Critical Care', 'hire_date': date(2017, 9, 5)},
            {'employee_id': 'DOC006', 'first_name': 'Rachel', 'last_name': 'Thompson', 'email': 'rachel.thompson@hospital.com', 'phone': '555-0106', 'role': StaffRole.DOCTOR, 'department': 'Maternity', 'specialization': 'Obstetrics & Gynecology', 'hire_date': date(2019, 8, 12)},
            {'employee_id': 'DOC007', 'first_name': 'Christopher', 'last_name': 'Anderson', 'email': 'christopher.anderson@hospital.com', 'phone': '555-0107', 'role': StaffRole.DOCTOR, 'department': 'Surgery', 'specialization': 'Orthopedic Surgery', 'hire_date': date(2020, 5, 3)},
            {'employee_id': 'DOC008', 'first_name': 'Jennifer', 'last_name': 'White', 'email': 'jennifer.white@hospital.com', 'phone': '555-0108', 'role': StaffRole.DOCTOR, 'department': 'Internal Medicine', 'specialization': 'Pulmonology', 'hire_date': date(2018, 11, 22)},
            {'employee_id': 'DOC009', 'first_name': 'Robert', 'last_name': 'Clark', 'email': 'robert.clark@hospital.com', 'phone': '555-0109', 'role': StaffRole.DOCTOR, 'department': 'Emergency Medicine', 'specialization': 'Emergency Medicine', 'hire_date': date(2021, 7, 15)},
            {'employee_id': 'DOC010', 'first_name': 'Lisa', 'last_name': 'Lopez', 'email': 'lisa.lopez@hospital.com', 'phone': '555-0110', 'role': StaffRole.DOCTOR, 'department': 'ICU', 'specialization': 'Critical Care', 'hire_date': date(2019, 4, 8)},
            {'employee_id': 'DOC011', 'first_name': 'Mark', 'last_name': 'Harris', 'email': 'mark.harris@hospital.com', 'phone': '555-0111', 'role': StaffRole.DOCTOR, 'department': 'Surgery', 'specialization': 'Cardiac Surgery', 'hire_date': date(2017, 12, 1)},
            {'employee_id': 'DOC012', 'first_name': 'Amanda', 'last_name': 'Young', 'email': 'amanda.young@hospital.com', 'phone': '555-0112', 'role': StaffRole.DOCTOR, 'department': 'Pediatrics', 'specialization': 'Pediatric Cardiology', 'hire_date': date(2020, 9, 14)},
            {'employee_id': 'DOC013', 'first_name': 'Thomas', 'last_name': 'Walker', 'email': 'thomas.walker@hospital.com', 'phone': '555-0113', 'role': StaffRole.DOCTOR, 'department': 'Internal Medicine', 'specialization': 'Neurology', 'hire_date': date(2018, 3, 7)},
            {'employee_id': 'DOC014', 'first_name': 'Michelle', 'last_name': 'Hall', 'email': 'michelle.hall@hospital.com', 'phone': '555-0114', 'role': StaffRole.DOCTOR, 'department': 'Emergency Medicine', 'specialization': 'Emergency Medicine', 'hire_date': date(2021, 1, 26)},
            {'employee_id': 'DOC015', 'first_name': 'Daniel', 'last_name': 'King', 'email': 'daniel.king@hospital.com', 'phone': '555-0115', 'role': StaffRole.DOCTOR, 'department': 'Surgery', 'specialization': 'Neurosurgery', 'hire_date': date(2019, 10, 11)},
            
            # Nurses (18 nurses)
            {'employee_id': 'NUR001', 'first_name': 'Lisa', 'last_name': 'Anderson', 'email': 'lisa.anderson@hospital.com', 'phone': '555-0201', 'role': StaffRole.NURSE, 'department': 'ICU', 'hire_date': date(2020, 4, 12)},
            {'employee_id': 'NUR002', 'first_name': 'Jennifer', 'last_name': 'Taylor', 'email': 'jennifer.taylor@hospital.com', 'phone': '555-0202', 'role': StaffRole.NURSE, 'department': 'Emergency', 'hire_date': date(2021, 1, 8)},
            {'employee_id': 'NUR003', 'first_name': 'Robert', 'last_name': 'Miller', 'email': 'robert.miller@hospital.com', 'phone': '555-0203', 'role': StaffRole.NURSE, 'department': 'General Medicine', 'hire_date': date(2019, 7, 22)},
            {'employee_id': 'NUR004', 'first_name': 'Amanda', 'last_name': 'Garcia', 'email': 'amanda.garcia@hospital.com', 'phone': '555-0204', 'role': StaffRole.NURSE, 'department': 'Surgery', 'hire_date': date(2020, 11, 3)},
            {'employee_id': 'NUR005', 'first_name': 'Kevin', 'last_name': 'Martinez', 'email': 'kevin.martinez@hospital.com', 'phone': '555-0205', 'role': StaffRole.NURSE, 'department': 'Pediatrics', 'hire_date': date(2021, 5, 17)},
            {'employee_id': 'NUR006', 'first_name': 'Michelle', 'last_name': 'Rodriguez', 'email': 'michelle.rodriguez@hospital.com', 'phone': '555-0206', 'role': StaffRole.NURSE, 'department': 'Maternity', 'hire_date': date(2019, 12, 1)},
            {'employee_id': 'NUR007', 'first_name': 'Brian', 'last_name': 'Lewis', 'email': 'brian.lewis@hospital.com', 'phone': '555-0207', 'role': StaffRole.NURSE, 'department': 'ICU', 'hire_date': date(2020, 8, 5)},
            {'employee_id': 'NUR008', 'first_name': 'Jessica', 'last_name': 'Lee', 'email': 'jessica.lee@hospital.com', 'phone': '555-0208', 'role': StaffRole.NURSE, 'department': 'Emergency', 'hire_date': date(2021, 3, 19)},
            {'employee_id': 'NUR009', 'first_name': 'Steven', 'last_name': 'Walker', 'email': 'steven.walker@hospital.com', 'phone': '555-0209', 'role': StaffRole.NURSE, 'department': 'General Medicine', 'hire_date': date(2019, 6, 14)},
            {'employee_id': 'NUR010', 'first_name': 'Nicole', 'last_name': 'Allen', 'email': 'nicole.allen@hospital.com', 'phone': '555-0210', 'role': StaffRole.NURSE, 'department': 'Surgery', 'hire_date': date(2020, 2, 27)},
            {'employee_id': 'NUR011', 'first_name': 'Matthew', 'last_name': 'Young', 'email': 'matthew.young@hospital.com', 'phone': '555-0211', 'role': StaffRole.NURSE, 'department': 'Pediatrics', 'hire_date': date(2021, 9, 8)},
            {'employee_id': 'NUR012', 'first_name': 'Ashley', 'last_name': 'Hernandez', 'email': 'ashley.hernandez@hospital.com', 'phone': '555-0212', 'role': StaffRole.NURSE, 'department': 'Maternity', 'hire_date': date(2019, 11, 23)},
            {'employee_id': 'NUR013', 'first_name': 'Joshua', 'last_name': 'King', 'email': 'joshua.king@hospital.com', 'phone': '555-0213', 'role': StaffRole.NURSE, 'department': 'ICU', 'hire_date': date(2020, 7, 16)},
            {'employee_id': 'NUR014', 'first_name': 'Stephanie', 'last_name': 'Wright', 'email': 'stephanie.wright@hospital.com', 'phone': '555-0214', 'role': StaffRole.NURSE, 'department': 'Emergency', 'hire_date': date(2021, 4, 12)},
            {'employee_id': 'NUR015', 'first_name': 'Andrew', 'last_name': 'Scott', 'email': 'andrew.scott@hospital.com', 'phone': '555-0215', 'role': StaffRole.NURSE, 'department': 'General Medicine', 'hire_date': date(2019, 8, 9)},
            {'employee_id': 'NUR016', 'first_name': 'Samantha', 'last_name': 'Green', 'email': 'samantha.green@hospital.com', 'phone': '555-0216', 'role': StaffRole.NURSE, 'department': 'Surgery', 'hire_date': date(2020, 12, 4)},
            {'employee_id': 'NUR017', 'first_name': 'Tyler', 'last_name': 'Adams', 'email': 'tyler.adams@hospital.com', 'phone': '555-0217', 'role': StaffRole.NURSE, 'department': 'Pediatrics', 'hire_date': date(2021, 6, 21)},
            {'employee_id': 'NUR018', 'first_name': 'Megan', 'last_name': 'Baker', 'email': 'megan.baker@hospital.com', 'phone': '555-0218', 'role': StaffRole.NURSE, 'department': 'Maternity', 'hire_date': date(2019, 9, 15)},
            
            # Technicians (6 technicians)
            {'employee_id': 'TEC001', 'first_name': 'James', 'last_name': 'Lee', 'email': 'james.lee@hospital.com', 'phone': '555-0301', 'role': StaffRole.TECHNICIAN, 'department': 'Radiology', 'hire_date': date(2020, 8, 14)},
            {'employee_id': 'TEC002', 'first_name': 'Maria', 'last_name': 'Gonzalez', 'email': 'maria.gonzalez@hospital.com', 'phone': '555-0302', 'role': StaffRole.TECHNICIAN, 'department': 'Laboratory', 'hire_date': date(2021, 3, 9)},
            {'employee_id': 'TEC003', 'first_name': 'Carlos', 'last_name': 'Nelson', 'email': 'carlos.nelson@hospital.com', 'phone': '555-0303', 'role': StaffRole.TECHNICIAN, 'department': 'Pharmacy', 'hire_date': date(2019, 5, 18)},
            {'employee_id': 'TEC004', 'first_name': 'Rebecca', 'last_name': 'Carter', 'email': 'rebecca.carter@hospital.com', 'phone': '555-0304', 'role': StaffRole.TECHNICIAN, 'department': 'Radiology', 'hire_date': date(2020, 10, 7)},
            {'employee_id': 'TEC005', 'first_name': 'Gregory', 'last_name': 'Mitchell', 'email': 'gregory.mitchell@hospital.com', 'phone': '555-0305', 'role': StaffRole.TECHNICIAN, 'department': 'Laboratory', 'hire_date': date(2021, 1, 25)},
            {'employee_id': 'TEC006', 'first_name': 'Laura', 'last_name': 'Perez', 'email': 'laura.perez@hospital.com', 'phone': '555-0306', 'role': StaffRole.TECHNICIAN, 'department': 'Pharmacy', 'hire_date': date(2019, 12, 12)},
            
            # Administrators (4 administrators)
            {'employee_id': 'ADM001', 'first_name': 'Charles', 'last_name': 'Thompson', 'email': 'charles.thompson@hospital.com', 'phone': '555-0401', 'role': StaffRole.ADMINISTRATOR, 'department': 'Administration', 'hire_date': date(2018, 1, 10)},
            {'employee_id': 'ADM002', 'first_name': 'Patricia', 'last_name': 'White', 'email': 'patricia.white@hospital.com', 'phone': '555-0402', 'role': StaffRole.ADMINISTRATOR, 'department': 'Administration', 'hire_date': date(2019, 4, 25)},
            {'employee_id': 'ADM003', 'first_name': 'Richard', 'last_name': 'Roberts', 'email': 'richard.roberts@hospital.com', 'phone': '555-0403', 'role': StaffRole.ADMINISTRATOR, 'department': 'Human Resources', 'hire_date': date(2020, 6, 8)},
            {'employee_id': 'ADM004', 'first_name': 'Susan', 'last_name': 'Turner', 'email': 'susan.turner@hospital.com', 'phone': '555-0404', 'role': StaffRole.ADMINISTRATOR, 'department': 'Finance', 'hire_date': date(2018, 9, 3)},
        ]
        
        for staff_info in staff_data:
            staff = Staff(**staff_info)
            db.session.add(staff)
        
        # Commit staff and beds first to get IDs
        db.session.commit()
        
        # Comprehensive Patients Data - 25+ patients
        patients_data = [
            {'patient_id': 'P001', 'first_name': 'Alice', 'last_name': 'Johnson', 'date_of_birth': date(1985, 3, 15), 'gender': Gender.FEMALE, 'phone': '555-1001', 'admission_type': AdmissionType.EMERGENCY, 'diagnosis': 'Chest pain, rule out MI', 'attending_physician': 'Dr. John Smith'},
            {'patient_id': 'P002', 'first_name': 'Bob', 'last_name': 'Williams', 'date_of_birth': date(1978, 7, 22), 'gender': Gender.MALE, 'phone': '555-1002', 'admission_type': AdmissionType.SCHEDULED, 'diagnosis': 'Elective cholecystectomy', 'attending_physician': 'Dr. Michael Brown'},
            {'patient_id': 'P003', 'first_name': 'Carol', 'last_name': 'Davis', 'date_of_birth': date(1992, 11, 8), 'gender': Gender.FEMALE, 'phone': '555-1003', 'admission_type': AdmissionType.EMERGENCY, 'diagnosis': 'Community-acquired pneumonia', 'attending_physician': 'Dr. Sarah Johnson'},
            {'patient_id': 'P004', 'first_name': 'Daniel', 'last_name': 'Miller', 'date_of_birth': date(2010, 5, 12), 'gender': Gender.MALE, 'phone': '555-1004', 'admission_type': AdmissionType.EMERGENCY, 'diagnosis': 'Acute asthma exacerbation', 'attending_physician': 'Dr. Emily Davis'},
            {'patient_id': 'P005', 'first_name': 'Eva', 'last_name': 'Garcia', 'date_of_birth': date(1987, 9, 3), 'gender': Gender.FEMALE, 'phone': '555-1005', 'admission_type': AdmissionType.EMERGENCY, 'diagnosis': 'Polytrauma from MVA', 'attending_physician': 'Dr. David Wilson'},
            {'patient_id': 'P006', 'first_name': 'Frank', 'last_name': 'Martinez', 'date_of_birth': date(1965, 12, 20), 'gender': Gender.MALE, 'phone': '555-1006', 'admission_type': AdmissionType.SCHEDULED, 'diagnosis': 'Hypertensive crisis', 'attending_physician': 'Dr. Sarah Johnson'},
            {'patient_id': 'P007', 'first_name': 'Grace', 'last_name': 'Anderson', 'date_of_birth': date(1990, 4, 18), 'gender': Gender.FEMALE, 'phone': '555-1007', 'admission_type': AdmissionType.EMERGENCY, 'diagnosis': 'Appendicitis', 'attending_physician': 'Dr. Christopher Anderson'},
            {'patient_id': 'P008', 'first_name': 'Henry', 'last_name': 'Taylor', 'date_of_birth': date(1955, 8, 7), 'gender': Gender.MALE, 'phone': '555-1008', 'admission_type': AdmissionType.SCHEDULED, 'diagnosis': 'Total knee replacement', 'attending_physician': 'Dr. Christopher Anderson'},
            {'patient_id': 'P009', 'first_name': 'Isabella', 'last_name': 'Thomas', 'date_of_birth': date(2015, 2, 14), 'gender': Gender.FEMALE, 'phone': '555-1009', 'admission_type': AdmissionType.EMERGENCY, 'diagnosis': 'Febrile seizures', 'attending_physician': 'Dr. Amanda Young'},
            {'patient_id': 'P010', 'first_name': 'Jack', 'last_name': 'Jackson', 'date_of_birth': date(1970, 6, 25), 'gender': Gender.MALE, 'phone': '555-1010', 'admission_type': AdmissionType.EMERGENCY, 'diagnosis': 'Acute stroke', 'attending_physician': 'Dr. Thomas Walker'},
            {'patient_id': 'P011', 'first_name': 'Katherine', 'last_name': 'White', 'date_of_birth': date(1995, 1, 30), 'gender': Gender.FEMALE, 'phone': '555-1011', 'admission_type': AdmissionType.SCHEDULED, 'diagnosis': 'Normal vaginal delivery', 'attending_physician': 'Dr. Rachel Thompson'},
            {'patient_id': 'P012', 'first_name': 'Louis', 'last_name': 'Harris', 'date_of_birth': date(1962, 10, 11), 'gender': Gender.MALE, 'phone': '555-1012', 'admission_type': AdmissionType.EMERGENCY, 'diagnosis': 'Acute myocardial infarction', 'attending_physician': 'Dr. Mark Harris'},
            {'patient_id': 'P013', 'first_name': 'Maria', 'last_name': 'Clark', 'date_of_birth': date(1988, 12, 3), 'gender': Gender.FEMALE, 'phone': '555-1013', 'admission_type': AdmissionType.EMERGENCY, 'diagnosis': 'Diabetic ketoacidosis', 'attending_physician': 'Dr. Jennifer White'},
            {'patient_id': 'P014', 'first_name': 'Nathan', 'last_name': 'Lewis', 'date_of_birth': date(2008, 7, 16), 'gender': Gender.MALE, 'phone': '555-1014', 'admission_type': AdmissionType.SCHEDULED, 'diagnosis': 'Tonsillectomy', 'attending_physician': 'Dr. Emily Davis'},
            {'patient_id': 'P015', 'first_name': 'Olivia', 'last_name': 'Robinson', 'date_of_birth': date(1983, 5, 9), 'gender': Gender.FEMALE, 'phone': '555-1015', 'admission_type': AdmissionType.EMERGENCY, 'diagnosis': 'Severe burns', 'attending_physician': 'Dr. Michelle Hall'},
            {'patient_id': 'P016', 'first_name': 'Peter', 'last_name': 'Walker', 'date_of_birth': date(1975, 9, 21), 'gender': Gender.MALE, 'phone': '555-1016', 'admission_type': AdmissionType.SCHEDULED, 'diagnosis': 'Hernia repair', 'attending_physician': 'Dr. Michael Brown'},
            {'patient_id': 'P017', 'first_name': 'Quinn', 'last_name': 'Hall', 'date_of_birth': date(2012, 3, 4), 'gender': Gender.MALE, 'phone': '555-1017', 'admission_type': AdmissionType.EMERGENCY, 'diagnosis': 'Fracture of femur', 'attending_physician': 'Dr. Christopher Anderson'},
            {'patient_id': 'P018', 'first_name': 'Rachel', 'last_name': 'Allen', 'date_of_birth': date(1991, 11, 27), 'gender': Gender.FEMALE, 'phone': '555-1018', 'admission_type': AdmissionType.SCHEDULED, 'diagnosis': 'C-section delivery', 'attending_physician': 'Dr. Rachel Thompson'},
            {'patient_id': 'P019', 'first_name': 'Samuel', 'last_name': 'Young', 'date_of_birth': date(1968, 4, 13), 'gender': Gender.MALE, 'phone': '555-1019', 'admission_type': AdmissionType.EMERGENCY, 'diagnosis': 'Pulmonary embolism', 'attending_physician': 'Dr. Jennifer White'},
            {'patient_id': 'P020', 'first_name': 'Tina', 'last_name': 'King', 'date_of_birth': date(1996, 8, 8), 'gender': Gender.FEMALE, 'phone': '555-1020', 'admission_type': AdmissionType.EMERGENCY, 'diagnosis': 'Drug overdose', 'attending_physician': 'Dr. Robert Clark'},
            {'patient_id': 'P021', 'first_name': 'Victor', 'last_name': 'Wright', 'date_of_birth': date(1952, 2, 19), 'gender': Gender.MALE, 'phone': '555-1021', 'admission_type': AdmissionType.SCHEDULED, 'diagnosis': 'Prostate surgery', 'attending_physician': 'Dr. Daniel King'},
            {'patient_id': 'P022', 'first_name': 'Wendy', 'last_name': 'Lopez', 'date_of_birth': date(1989, 6, 15), 'gender': Gender.FEMALE, 'phone': '555-1022', 'admission_type': AdmissionType.EMERGENCY, 'diagnosis': 'Severe allergic reaction', 'attending_physician': 'Dr. John Smith'},
            {'patient_id': 'P023', 'first_name': 'Xavier', 'last_name': 'Hill', 'date_of_birth': date(2013, 1, 22), 'gender': Gender.MALE, 'phone': '555-1023', 'admission_type': AdmissionType.EMERGENCY, 'diagnosis': 'Bronchiolitis', 'attending_physician': 'Dr. Amanda Young'},
            {'patient_id': 'P024', 'first_name': 'Yvonne', 'last_name': 'Scott', 'date_of_birth': date(1993, 10, 6), 'gender': Gender.FEMALE, 'phone': '555-1024', 'admission_type': AdmissionType.SCHEDULED, 'diagnosis': 'Postpartum care', 'attending_physician': 'Dr. Rachel Thompson'},
            {'patient_id': 'P025', 'first_name': 'Zachary', 'last_name': 'Green', 'date_of_birth': date(1981, 12, 31), 'gender': Gender.MALE, 'phone': '555-1025', 'admission_type': AdmissionType.EMERGENCY, 'diagnosis': 'Acute pancreatitis', 'attending_physician': 'Dr. Sarah Johnson'},
        ]
        
        for patient_info in patients_data:
            patient_info['admission_date'] = datetime.utcnow() - timedelta(days=random.randint(0, 10))
            patient = Patient(**patient_info)
            db.session.add(patient)
        
        db.session.commit()
        
        # Create realistic allocations
        patients = Patient.query.all()
        beds = Bed.query.all()
        staff = Staff.query.all()
        
        # Allocate beds to patients (about 75% occupancy, but not more than available patients)
        max_allocations = min(int(len(beds) * 0.75), len(patients))
        occupied_beds = random.sample(beds, max_allocations)
        allocated_patients = random.sample(patients, max_allocations)
        
        for i, (bed, patient) in enumerate(zip(occupied_beds, allocated_patients)):
            allocator = random.choice([s for s in staff if s.role in [StaffRole.DOCTOR, StaffRole.ADMINISTRATOR]])
            
            allocation = BedAllocation(
                bed_id=bed.id,
                patient_id=patient.id,
                allocated_by=allocator.id,
                start_date=patient.admission_date,
                notes=f'Admitted to {bed.ward} ward - {patient.diagnosis}'
            )
            
            # Mark bed as occupied
            bed.status = BedStatus.OCCUPIED
            db.session.add(allocation)
        
        # Set some beds to maintenance (about 5%)
        maintenance_beds = random.sample([b for b in beds if b.status == BedStatus.AVAILABLE], 
                                       max(1, int(len(beds) * 0.05)))
        for bed in maintenance_beds:
            bed.status = BedStatus.MAINTENANCE
        
        # Create comprehensive staff schedules for the current week
        today = date.today()
        for i in range(7):  # Next 7 days
            schedule_date = today + timedelta(days=i)
            
            # Schedule doctors and nurses only
            medical_staff = [s for s in staff if s.role in [StaffRole.DOCTOR, StaffRole.NURSE]]
            
            for j, staff_member in enumerate(medical_staff):
                # Not everyone works every day
                if random.random() < 0.85:  # 85% chance of being scheduled
                    shift_types = [ShiftType.MORNING, ShiftType.EVENING, ShiftType.NIGHT]
                    shift_type = shift_types[j % 3]
                    
                    if shift_type == ShiftType.MORNING:
                        start_time = time(7, 0)
                        end_time = time(15, 0)
                    elif shift_type == ShiftType.EVENING:
                        start_time = time(15, 0)
                        end_time = time(23, 0)
                    else:  # Night
                        start_time = time(23, 0)
                        end_time = time(7, 0)
                    
                    schedule = StaffSchedule(
                        staff_id=staff_member.id,
                        date=schedule_date,
                        shift_type=shift_type,
                        start_time=start_time,
                        end_time=end_time,
                        ward=staff_member.department
                    )
                    db.session.add(schedule)
        
        # Create staff allocations for current shift
        current_shift_staff = [s for s in medical_staff if random.random() < 0.4]  # 40% on current shift
        
        for staff_member in current_shift_staff:
            allocation = StaffAllocation(
                staff_id=staff_member.id,
                ward=staff_member.department,
                shift_type=ShiftType.MORNING,  # Current shift
                start_time=datetime.utcnow() - timedelta(hours=random.randint(1, 8)),
                notes=f'{staff_member.full_name} assigned to {staff_member.department}'
            )
            db.session.add(allocation)
        
        db.session.commit()
        print("✅ Comprehensive sample data has been successfully loaded!")
        print(f"📊 Created: {len(beds_data)} beds, {len(staff_data)} staff members, {len(patients_data)} patients")
        print(f"🏥 Bed occupancy: ~75%, Staff scheduled for next 7 days")
        
    except Exception as e:
        db.session.rollback()
        print(f"❌ Error initializing sample data: {str(e)}")
        raise 